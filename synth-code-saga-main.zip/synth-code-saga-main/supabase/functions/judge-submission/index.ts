import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth) return new Response(JSON.stringify({ error: "unauthenticated" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );
    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: auth } } },
    );
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "unauthenticated" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const body = await req.json();
    const { challenge_id, code, mode, time_taken } = body;
    if (!challenge_id || typeof code !== "string") {
      return new Response(JSON.stringify({ error: "bad input" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { data: challenge } = await supabase.from("challenges").select("*").eq("id", challenge_id).maybeSingle();
    if (!challenge) return new Response(JSON.stringify({ error: "challenge not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    let passed = false;
    let score = 0;
    let feedback = "";

    // Step 1: expected output exact match
    if (challenge.expected_output) {
      const cleaned = code.toLowerCase();
      const expected = String(challenge.expected_output).trim();
      if (cleaned.includes(expected.toLowerCase()) || cleaned.includes(JSON.stringify(expected).toLowerCase())) {
        passed = true; score = 90;
        feedback = "Output matches expected.";
      }
    }

    // Step 2: AI rubric judge if not yet passed and rubric exists
    if (!passed && challenge.rubric) {
      const apiKey = Deno.env.get("LOVABLE_API_KEY");
      if (apiKey) {
        try {
          const aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
            method: "POST",
            headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
            body: JSON.stringify({
              model: "google/gemini-3-flash-preview",
              messages: [
                { role: "system", content: "You are a strict but fair coding judge. Reply with JSON only: {\"passed\":boolean,\"score\":0-100,\"feedback\":string}. Be concise." },
                { role: "user", content: `Language: ${challenge.language}\nProblem: ${challenge.description}\nRubric: ${challenge.rubric}\nExpected output (if any): ${challenge.expected_output ?? "n/a"}\n\nUser submission:\n\`\`\`\n${code.slice(0, 4000)}\n\`\`\`\n\nRespond with JSON only.` },
              ],
            }),
          });
          if (aiResp.ok) {
            const j = await aiResp.json();
            const text = j.choices?.[0]?.message?.content ?? "";
            const m = text.match(/\{[\s\S]*\}/);
            if (m) {
              const parsed = JSON.parse(m[0]);
              passed = !!parsed.passed;
              score = Math.max(0, Math.min(100, Number(parsed.score) || 0));
              feedback = String(parsed.feedback || "").slice(0, 500);
            }
          } else if (aiResp.status === 429) {
            feedback = "AI judge is busy — try again in a moment.";
          } else if (aiResp.status === 402) {
            feedback = "AI credits exhausted. Add funds in Settings → Workspace → Usage.";
          }
        } catch (_) { /* ignore */ }
      }
    }

    if (!feedback) feedback = passed ? "Nice work!" : "Output didn't match. Re-read the brief and try again.";

    // Rewards: only in non-failed runs; timed bonus
    let xp_awarded = 0, coins_awarded = 0;
    if (passed && mode !== "timeout") {
      const diffMult: Record<string, number> = { beginner: 1, intermediate: 1.5, advanced: 2, expert: 3, legendary: 5 };
      const m = diffMult[challenge.difficulty] ?? 1;
      let speedMult = 1;
      if (mode === "challenge" && time_taken && challenge.time_limit_seconds) {
        const ratio = time_taken / challenge.time_limit_seconds;
        if (ratio < 0.5 && score >= 90) speedMult = 1.5; // jackpot
        else if (ratio < 0.8) speedMult = 1.2;
      }
      const practiceMult = mode === "practice" ? 0.5 : 1;
      xp_awarded = Math.round(challenge.base_xp * m * speedMult * practiceMult);
      coins_awarded = Math.round(challenge.base_coins * m * speedMult * practiceMult);
    }

    // Record submission
    await supabase.from("submissions").insert({
      user_id: user.id, challenge_id, code: code.slice(0, 8000), passed, score,
      time_taken_seconds: time_taken ?? null, ai_feedback: feedback, mode: mode ?? "practice",
    });

    // Update profile + ledgers
    if (passed) {
      const { data: prof } = await supabase.from("profiles").select("xp,coins,total_submissions,total_passed").eq("id", user.id).maybeSingle();
      if (prof) {
        await supabase.from("profiles").update({
          xp: prof.xp + xp_awarded,
          coins: prof.coins + coins_awarded,
          total_submissions: prof.total_submissions + 1,
          total_passed: prof.total_passed + 1,
        }).eq("id", user.id);
        if (xp_awarded > 0) await supabase.from("xp_ledger").insert({ user_id: user.id, amount: xp_awarded, reason: "challenge_solved", ref_id: challenge_id });
        if (coins_awarded > 0) await supabase.from("coin_ledger").insert({ user_id: user.id, amount: coins_awarded, reason: "challenge_solved", ref_id: challenge_id });
      }
    } else {
      await supabase.rpc("noop").catch(() => {});
      const { data: prof } = await supabase.from("profiles").select("total_submissions").eq("id", user.id).maybeSingle();
      if (prof) await supabase.from("profiles").update({ total_submissions: prof.total_submissions + 1 }).eq("id", user.id);
    }

    return new Response(JSON.stringify({ passed, score, feedback, xp_awarded, coins_awarded }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("judge error", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "unknown" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
