import { ComingSoon } from "@/components/ComingSoon";
export default function Battle() { return <ComingSoon title="Battle Arena" desc="Live 1v1 matchmaking with synced timers and instant-win on first correct solve. Coming in the next iteration." />; }
