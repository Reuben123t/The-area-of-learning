import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AppLayout } from "@/components/AppLayout";
import { useAuth } from "@/lib/auth-context";
import { useTheme } from "@/lib/theme-context";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import type { Theme } from "@/lib/game";

export default function ProfileEdit() {
  const { profile, refreshProfile } = useAuth();
  const { theme, setTheme } = useTheme();
  const [bio, setBio] = useState("");
  const [country, setCountry] = useState("US");
  const [display, setDisplay] = useState("");
  const navigate = useNavigate();
  useEffect(() => { if (profile) { setBio(profile.bio ?? ""); setCountry(profile.country_code ?? "US"); setDisplay(profile.display_name ?? ""); } }, [profile]);
  const save = async () => {
    if (!profile) return;
    const { error } = await supabase.from("profiles").update({ bio: bio.slice(0, 280), country_code: country.slice(0, 2).toUpperCase(), display_name: display.slice(0, 40), theme }).eq("id", profile.id);
    if (error) toast.error(error.message); else { toast.success("Saved!"); await refreshProfile(); navigate(`/profile/${profile.username}`); }
  };
  if (!profile) return null;
  return (
    <AppLayout>
      <div className="glass rounded-2xl p-6 max-w-xl">
        <h1 className="text-2xl font-extrabold mb-4">Edit profile</h1>
        <div className="space-y-3">
          <div><Label>Display name</Label><Input value={display} onChange={(e) => setDisplay(e.target.value)} maxLength={40} /></div>
          <div><Label>Bio</Label><Textarea value={bio} onChange={(e) => setBio(e.target.value)} maxLength={280} rows={3} /></div>
          <div><Label>Country (2-letter)</Label><Input value={country} onChange={(e) => setCountry(e.target.value)} maxLength={2} /></div>
          <div>
            <Label>Theme</Label>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {(["neon","aurora","retro","minimal"] as Theme[]).map((t) => (
                <button key={t} onClick={() => setTheme(t)} className={`rounded-lg p-3 text-left capitalize ${theme === t ? "grad-1 text-primary-foreground" : "glass"}`}>{t}</button>
              ))}
            </div>
          </div>
          <Button onClick={save} className="grad-1 border-0 text-primary-foreground glow w-full">Save</Button>
        </div>
      </div>
    </AppLayout>
  );
}
