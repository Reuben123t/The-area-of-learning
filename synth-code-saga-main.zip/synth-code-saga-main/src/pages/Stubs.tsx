import { ComingSoon } from "@/components/ComingSoon";
export const House = () => <ComingSoon title="Your House" desc="Buy a tier, place furniture on a grid, and let friends visit. Catalog and tiers are seeded — UI ships next." />;
export const Characters = () => <ComingSoon title="Characters" desc="5 unlockable characters with emotes and victory poses. Equip from your profile." />;
export const Friends = () => <ComingSoon title="Friends" desc="Add friends, see them online, invite to battles." />;
export const Quests = () => <ComingSoon title="Daily Quests" desc="3 quests refresh every day at midnight UTC." />;
export const Spin = () => <ComingSoon title="Spin Wheel" desc="One free spin daily. Coins, items, and rare characters." />;
export const Tournaments = () => <ComingSoon title="Tournaments" desc="Weekly brackets with coin prize pools." />;
export const BattlePass = () => <ComingSoon title="Battle Pass" desc="Season 1: Genesis is live. Earn XP to unlock 30 tiers." />;
export const Admin = () => <ComingSoon title="Admin Console" desc="Super-admin powers: ban users, edit shop, broadcast announcements, view logs, manage tournaments." />;
