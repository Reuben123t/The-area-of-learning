// CodeArena shared types
export type Theme = "neon" | "aurora" | "retro" | "minimal";
export type Difficulty = "beginner" | "intermediate" | "advanced" | "expert" | "legendary";
export type Language = "python" | "javascript" | "html" | "css" | "cpp" | "java";
export type RankTier = "bronze" | "silver" | "gold" | "platinum" | "diamond" | "master" | "grandmaster";
export type AppRole = "user" | "moderator" | "admin" | "super_admin";

export const LANGUAGES: { id: Language; label: string; emoji: string; color: string }[] = [
  { id: "python", label: "Python", emoji: "🐍", color: "from-yellow-400 to-blue-500" },
  { id: "javascript", label: "JavaScript", emoji: "📜", color: "from-yellow-300 to-yellow-500" },
  { id: "html", label: "HTML", emoji: "🧱", color: "from-orange-500 to-red-500" },
  { id: "css", label: "CSS", emoji: "🎨", color: "from-blue-400 to-purple-500" },
  { id: "cpp", label: "C++", emoji: "⚙️", color: "from-blue-500 to-indigo-700" },
  { id: "java", label: "Java", emoji: "☕", color: "from-orange-600 to-red-700" },
];

export const DIFFICULTIES: { id: Difficulty; label: string; color: string; xpMult: number }[] = [
  { id: "beginner", label: "Beginner", color: "text-success", xpMult: 1 },
  { id: "intermediate", label: "Intermediate", color: "text-primary", xpMult: 1.5 },
  { id: "advanced", label: "Advanced", color: "text-secondary", xpMult: 2 },
  { id: "expert", label: "Expert", color: "text-warning", xpMult: 3 },
  { id: "legendary", label: "Legendary", color: "text-destructive", xpMult: 5 },
];

export const RANK_TIERS: { id: RankTier; label: string; minPoints: number; color: string }[] = [
  { id: "bronze", label: "Bronze", minPoints: 0, color: "text-rank-bronze" },
  { id: "silver", label: "Silver", minPoints: 500, color: "text-rank-silver" },
  { id: "gold", label: "Gold", minPoints: 1200, color: "text-rank-gold" },
  { id: "platinum", label: "Platinum", minPoints: 2200, color: "text-rank-platinum" },
  { id: "diamond", label: "Diamond", minPoints: 3500, color: "text-rank-diamond" },
  { id: "master", label: "Master", minPoints: 5500, color: "text-rank-master" },
  { id: "grandmaster", label: "Grandmaster", minPoints: 8000, color: "text-rank-grandmaster" },
];

export function tierFromPoints(p: number): RankTier {
  let t: RankTier = "bronze";
  for (const r of RANK_TIERS) if (p >= r.minPoints) t = r.id;
  return t;
}

export function levelFromXp(xp: number): { level: number; current: number; required: number } {
  // level n requires 100 * n^1.5 XP
  let level = 1;
  let acc = 0;
  while (true) {
    const need = Math.floor(100 * Math.pow(level, 1.5));
    if (acc + need > xp) return { level, current: xp - acc, required: need };
    acc += need;
    level++;
    if (level > 999) return { level, current: 0, required: need };
  }
}
