import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import type { Theme } from "@/lib/game";

type Ctx = {
  theme: Theme;
  setTheme: (t: Theme) => void;
  light: boolean;
  setLight: (l: boolean) => void;
};
const ThemeCtx = createContext<Ctx | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(() => (localStorage.getItem("ca:theme") as Theme) || "neon");
  const [light, setLightState] = useState<boolean>(() => localStorage.getItem("ca:light") === "1");

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("theme-neon", "theme-aurora", "theme-retro", "theme-minimal");
    root.classList.add(`theme-${theme}`);
    root.classList.toggle("light", light);
    root.classList.toggle("dark", !light);
    localStorage.setItem("ca:theme", theme);
    localStorage.setItem("ca:light", light ? "1" : "0");
  }, [theme, light]);

  return (
    <ThemeCtx.Provider value={{ theme, setTheme: setThemeState, light, setLight: setLightState }}>
      {children}
    </ThemeCtx.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeCtx);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}
