import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { ParticleBackground } from "@/components/ParticleBackground";
import { RobotMascot } from "@/components/RobotMascot";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

const signupSchema = z.object({
  username: z.string().trim().min(3).max(24).regex(/^[a-zA-Z0-9_]+$/, "Letters, numbers and underscore only"),
  email: z.string().trim().email().max(255),
  password: z.string().min(8).max(72),
});
const signinSchema = z.object({
  email: z.string().trim().email().max(255),
  password: z.string().min(1).max(72),
});

export default function Auth() {
  const [params] = useSearchParams();
  const initialMode = params.get("mode") === "signup" ? "signup" : "signin";
  const [mode, setMode] = useState<"signin" | "signup" | "forgot">(initialMode);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    if (user) navigate("/dashboard", { replace: true });
  }, [user, navigate]);

  const handleGoogle = async () => {
    setBusy(true);
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/dashboard` },
    });
    if (error) toast.error(error.message);
    setBusy(false);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const parsed = signupSchema.safeParse({ username, email, password });
        if (!parsed.success) {
          toast.error(parsed.error.issues[0].message);
          return;
        }
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/dashboard`,
            data: { username, display_name: username },
          },
        });
        if (error) {
          toast.error(error.message);
          return;
        }
        toast.success("Welcome! Check your email to verify your account.");
        navigate("/dashboard");
      } else if (mode === "signin") {
        const parsed = signinSchema.safeParse({ email, password });
        if (!parsed.success) {
          toast.error(parsed.error.issues[0].message);
          return;
        }
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
          toast.error(error.message);
          return;
        }
        navigate("/dashboard");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) toast.error(error.message);
        else toast.success("Reset link sent. Check your email.");
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="relative min-h-screen grid md:grid-cols-2">
      <ParticleBackground />

      <div className="hidden md:flex flex-col justify-between p-10 relative">
        <Link to="/" className="flex items-center gap-2 font-bold">
          <div className="grid h-9 w-9 place-items-center rounded-lg grad-1 text-primary-foreground glow font-mono">
            {"</>"}
          </div>
          <span className="grad-text">CodeArena</span>
        </Link>
        <div>
          <RobotMascot state="happy" size={140} message="Welcome back, coder!" />
          <h2 className="mt-6 text-3xl font-extrabold tracking-tight">
            Step into <span className="grad-text">the arena.</span>
          </h2>
          <p className="mt-2 text-sm text-muted-foreground max-w-md">
            Six languages. Five difficulty tiers. Seven ranks. Infinite levels. One robot mascot
            who&apos;s really proud of you.
          </p>
        </div>
        <div className="text-xs text-muted-foreground">© CodeArena</div>
      </div>

      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm glass rounded-2xl p-8">
          <Link to="/" className="md:hidden flex items-center gap-2 font-bold mb-6">
            <div className="grid h-8 w-8 place-items-center rounded-lg grad-1 text-primary-foreground font-mono text-sm">
              {"</>"}
            </div>
            <span className="grad-text">CodeArena</span>
          </Link>

          <h1 className="text-2xl font-bold">
            {mode === "signup" ? "Create your account" : mode === "signin" ? "Welcome back" : "Reset password"}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {mode === "signup"
              ? "Pick a username — it&apos;s your handle in the arena."
              : mode === "signin"
                ? "Sign in to continue your streak."
                : "We'll email you a reset link."}
          </p>

          {mode !== "forgot" && (
            <Button onClick={handleGoogle} disabled={busy} variant="outline" className="w-full mt-6 h-11">
              <svg className="h-5 w-5" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23z"/><path fill="#FBBC05" d="M5.84 14.1A6.6 6.6 0 0 1 5.5 12c0-.73.13-1.43.34-2.1V7.07H2.18A11 11 0 0 0 1 12c0 1.78.43 3.46 1.18 4.93l3.66-2.83z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.83C6.71 7.31 9.14 5.38 12 5.38z"/></svg>
              Continue with Google
            </Button>
          )}

          {mode !== "forgot" && (
            <div className="my-4 flex items-center gap-3 text-xs text-muted-foreground">
              <div className="h-px flex-1 bg-border" />
              or
              <div className="h-px flex-1 bg-border" />
            </div>
          )}

          <form onSubmit={submit} className="space-y-3">
            {mode === "signup" && (
              <div className="space-y-1.5">
                <Label htmlFor="username">Username</Label>
                <Input id="username" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Coder_Master3012" autoComplete="username" required maxLength={24} />
              </div>
            )}
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required maxLength={255} />
            </div>
            {mode !== "forgot" && (
              <div className="space-y-1.5">
                <Label htmlFor="password">Password</Label>
                <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === "signup" ? "new-password" : "current-password"} required minLength={8} maxLength={72} />
              </div>
            )}

            <Button type="submit" disabled={busy} className="w-full h-11 grad-1 border-0 text-primary-foreground glow mt-2">
              {busy ? "..." : mode === "signup" ? "Create account" : mode === "signin" ? "Sign in" : "Send reset link"}
            </Button>
          </form>

          <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
            {mode === "signin" ? (
              <>
                <button onClick={() => setMode("forgot")} className="hover:text-foreground">Forgot password?</button>
                <button onClick={() => setMode("signup")} className="hover:text-foreground">Create account →</button>
              </>
            ) : mode === "signup" ? (
              <button onClick={() => setMode("signin")} className="ml-auto hover:text-foreground">Already have an account?</button>
            ) : (
              <button onClick={() => setMode("signin")} className="ml-auto hover:text-foreground">Back to sign in</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
