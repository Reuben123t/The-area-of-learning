import { Coins, Gem, Flame, Trophy } from "lucide-react";
import { Link, NavLink } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { useTheme } from "@/lib/theme-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { levelFromXp, RANK_TIERS } from "@/lib/game";

export function GameNav() {
  const { user, profile, isAdmin, signOut } = useAuth();
  const { theme, setTheme, light, setLight } = useTheme();
  const lvl = profile ? levelFromXp(profile.xp) : null;
  const rank = profile ? RANK_TIERS.find((r) => r.id === profile.rank_tier) : null;

  const links = [
    { to: "/dashboard", label: "Home" },
    { to: "/learn", label: "Learn" },
    { to: "/battle", label: "Battle" },
    { to: "/leaderboard", label: "Ranks" },
    { to: "/shop", label: "Shop" },
    { to: "/house", label: "House" },
    { to: "/quests", label: "Quests" },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/50 glass">
      <div className="container flex h-16 items-center justify-between gap-4">
        <Link to="/dashboard" className="flex items-center gap-2 font-bold">
          <div className="grid h-9 w-9 place-items-center rounded-lg grad-1 text-primary-foreground glow font-mono text-base">
            {"</>"}
          </div>
          <span className="grad-text text-lg tracking-tight hidden sm:inline">CodeArena</span>
        </Link>

        {user && (
          <nav className="hidden md:flex items-center gap-1">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                className={({ isActive }) =>
                  `rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
                    isActive ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                  }`
                }
              >
                {l.label}
              </NavLink>
            ))}
            {isAdmin && (
              <NavLink
                to="/admin"
                className={({ isActive }) =>
                  `rounded-md px-3 py-1.5 text-sm font-medium ${
                    isActive ? "bg-secondary/20 text-secondary" : "text-secondary hover:bg-secondary/10"
                  }`
                }
              >
                Admin
              </NavLink>
            )}
          </nav>
        )}

        <div className="flex items-center gap-2">
          {profile ? (
            <>
              <div className="hidden sm:flex items-center gap-3 rounded-full glass px-3 py-1 text-sm">
                <span className="flex items-center gap-1 text-coin">
                  <Coins className="h-4 w-4" />
                  <span className="font-mono font-semibold">{profile.coins}</span>
                </span>
                <span className="flex items-center gap-1 text-gem">
                  <Gem className="h-4 w-4" />
                  <span className="font-mono font-semibold">{profile.gems}</span>
                </span>
                {profile.current_streak > 0 && (
                  <span className="flex items-center gap-1 text-warning">
                    <Flame className="h-4 w-4" />
                    <span className="font-mono font-semibold">{profile.current_streak}</span>
                  </span>
                )}
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-2 rounded-full glass px-2 py-1 hover:bg-muted/40 transition">
                    <div className="grid h-8 w-8 place-items-center rounded-full grad-1 font-bold text-primary-foreground">
                      {profile.username.slice(0, 1).toUpperCase()}
                    </div>
                    <div className="hidden md:block text-left leading-tight">
                      <div className="text-xs font-semibold">{profile.username}</div>
                      <div className="text-[10px] text-muted-foreground">
                        Lv {lvl?.level} · {rank?.label}
                      </div>
                    </div>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-52">
                  <DropdownMenuItem asChild>
                    <Link to={`/profile/${profile.username}`}>My profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/profile/edit">Edit profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/friends">Friends</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/characters">Characters</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/battle-pass">Battle Pass</Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <div className="px-2 py-1.5 text-[10px] uppercase text-muted-foreground">Theme</div>
                  {(["neon", "aurora", "retro", "minimal"] as const).map((t) => (
                    <DropdownMenuItem key={t} onClick={() => setTheme(t)}>
                      <span className="capitalize">{t}</span>
                      {theme === t && <span className="ml-auto text-primary">●</span>}
                    </DropdownMenuItem>
                  ))}
                  <DropdownMenuItem onClick={() => setLight(!light)}>
                    {light ? "Dark mode" : "Light mode"}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={signOut}>Sign out</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <Button asChild size="sm" className="grad-1 text-primary-foreground border-0 glow">
              <Link to="/auth">Enter the Arena</Link>
            </Button>
          )}
        </div>
      </div>

      {/* Mobile nav */}
      {user && (
        <nav className="md:hidden flex items-center justify-around border-t border-border/50 px-2 py-1 overflow-x-auto">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `rounded-md px-2 py-1 text-xs whitespace-nowrap ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
      )}
    </header>
  );
}
