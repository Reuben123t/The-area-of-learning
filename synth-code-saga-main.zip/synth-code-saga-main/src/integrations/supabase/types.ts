export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      achievements: {
        Row: {
          coin_reward: number | null
          description: string | null
          hidden: boolean | null
          icon: string | null
          id: string
          name: string
          slug: string
          xp_reward: number | null
        }
        Insert: {
          coin_reward?: number | null
          description?: string | null
          hidden?: boolean | null
          icon?: string | null
          id?: string
          name: string
          slug: string
          xp_reward?: number | null
        }
        Update: {
          coin_reward?: number | null
          description?: string | null
          hidden?: boolean | null
          icon?: string | null
          id?: string
          name?: string
          slug?: string
          xp_reward?: number | null
        }
        Relationships: []
      }
      announcements: {
        Row: {
          active: boolean | null
          body: string | null
          created_at: string | null
          created_by: string | null
          id: string
          level: string | null
          title: string
        }
        Insert: {
          active?: boolean | null
          body?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          level?: string | null
          title: string
        }
        Update: {
          active?: boolean | null
          body?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          level?: string | null
          title?: string
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string | null
          details: Json | null
          id: string
          target_id: string | null
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string | null
          details?: Json | null
          id?: string
          target_id?: string | null
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string | null
          details?: Json | null
          id?: string
          target_id?: string | null
        }
        Relationships: []
      }
      battle_participants: {
        Row: {
          battle_id: string
          finished: boolean | null
          finished_at: string | null
          id: string
          passed: boolean | null
          progress: number | null
          user_id: string
        }
        Insert: {
          battle_id: string
          finished?: boolean | null
          finished_at?: string | null
          id?: string
          passed?: boolean | null
          progress?: number | null
          user_id: string
        }
        Update: {
          battle_id?: string
          finished?: boolean | null
          finished_at?: string | null
          id?: string
          passed?: boolean | null
          progress?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "battle_participants_battle_id_fkey"
            columns: ["battle_id"]
            isOneToOne: false
            referencedRelation: "battles"
            referencedColumns: ["id"]
          },
        ]
      }
      battle_pass_progress: {
        Row: {
          claimed_tiers: number[] | null
          id: string
          premium: boolean | null
          season_id: string
          user_id: string
          xp: number | null
        }
        Insert: {
          claimed_tiers?: number[] | null
          id?: string
          premium?: boolean | null
          season_id: string
          user_id: string
          xp?: number | null
        }
        Update: {
          claimed_tiers?: number[] | null
          id?: string
          premium?: boolean | null
          season_id?: string
          user_id?: string
          xp?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "battle_pass_progress_season_id_fkey"
            columns: ["season_id"]
            isOneToOne: false
            referencedRelation: "battle_pass_seasons"
            referencedColumns: ["id"]
          },
        ]
      }
      battle_pass_seasons: {
        Row: {
          active: boolean | null
          ends_at: string
          id: string
          name: string
          rewards: Json | null
          starts_at: string
        }
        Insert: {
          active?: boolean | null
          ends_at: string
          id?: string
          name: string
          rewards?: Json | null
          starts_at: string
        }
        Update: {
          active?: boolean | null
          ends_at?: string
          id?: string
          name?: string
          rewards?: Json | null
          starts_at?: string
        }
        Relationships: []
      }
      battles: {
        Row: {
          challenge_id: string
          created_at: string | null
          ends_at: string | null
          id: string
          ranked: boolean | null
          starts_at: string | null
          status: Database["public"]["Enums"]["battle_status"] | null
          winner_id: string | null
        }
        Insert: {
          challenge_id: string
          created_at?: string | null
          ends_at?: string | null
          id?: string
          ranked?: boolean | null
          starts_at?: string | null
          status?: Database["public"]["Enums"]["battle_status"] | null
          winner_id?: string | null
        }
        Update: {
          challenge_id?: string
          created_at?: string | null
          ends_at?: string | null
          id?: string
          ranked?: boolean | null
          starts_at?: string | null
          status?: Database["public"]["Enums"]["battle_status"] | null
          winner_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "battles_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "challenges"
            referencedColumns: ["id"]
          },
        ]
      }
      challenges: {
        Row: {
          active: boolean | null
          base_coins: number | null
          base_xp: number | null
          created_at: string | null
          created_by: string | null
          description: string
          difficulty: Database["public"]["Enums"]["difficulty_tier"]
          expected_output: string | null
          hints: string[] | null
          id: string
          language: Database["public"]["Enums"]["code_language"]
          rubric: string | null
          starter_code: string | null
          tags: string[] | null
          time_limit_seconds: number | null
          title: string
          updated_at: string | null
        }
        Insert: {
          active?: boolean | null
          base_coins?: number | null
          base_xp?: number | null
          created_at?: string | null
          created_by?: string | null
          description: string
          difficulty: Database["public"]["Enums"]["difficulty_tier"]
          expected_output?: string | null
          hints?: string[] | null
          id?: string
          language: Database["public"]["Enums"]["code_language"]
          rubric?: string | null
          starter_code?: string | null
          tags?: string[] | null
          time_limit_seconds?: number | null
          title: string
          updated_at?: string | null
        }
        Update: {
          active?: boolean | null
          base_coins?: number | null
          base_xp?: number | null
          created_at?: string | null
          created_by?: string | null
          description?: string
          difficulty?: Database["public"]["Enums"]["difficulty_tier"]
          expected_output?: string | null
          hints?: string[] | null
          id?: string
          language?: Database["public"]["Enums"]["code_language"]
          rubric?: string | null
          starter_code?: string | null
          tags?: string[] | null
          time_limit_seconds?: number | null
          title?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      characters: {
        Row: {
          active: boolean | null
          color_accent: string | null
          color_primary: string | null
          description: string | null
          emoji: string | null
          id: string
          name: string
          price_coins: number | null
          rarity: string | null
          slug: string
          unlock_condition: string | null
        }
        Insert: {
          active?: boolean | null
          color_accent?: string | null
          color_primary?: string | null
          description?: string | null
          emoji?: string | null
          id?: string
          name: string
          price_coins?: number | null
          rarity?: string | null
          slug: string
          unlock_condition?: string | null
        }
        Update: {
          active?: boolean | null
          color_accent?: string | null
          color_primary?: string | null
          description?: string | null
          emoji?: string | null
          id?: string
          name?: string
          price_coins?: number | null
          rarity?: string | null
          slug?: string
          unlock_condition?: string | null
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          channel: string
          content: string
          created_at: string | null
          deleted: boolean | null
          id: string
          user_id: string
        }
        Insert: {
          channel?: string
          content: string
          created_at?: string | null
          deleted?: boolean | null
          id?: string
          user_id: string
        }
        Update: {
          channel?: string
          content?: string
          created_at?: string | null
          deleted?: boolean | null
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      cheat_events: {
        Row: {
          battle_id: string | null
          challenge_id: string | null
          created_at: string | null
          details: Json | null
          event_type: string
          id: string
          severity: number | null
          user_id: string
        }
        Insert: {
          battle_id?: string | null
          challenge_id?: string | null
          created_at?: string | null
          details?: Json | null
          event_type: string
          id?: string
          severity?: number | null
          user_id: string
        }
        Update: {
          battle_id?: string | null
          challenge_id?: string | null
          created_at?: string | null
          details?: Json | null
          event_type?: string
          id?: string
          severity?: number | null
          user_id?: string
        }
        Relationships: []
      }
      coin_ledger: {
        Row: {
          amount: number
          created_at: string | null
          id: string
          reason: string
          ref_id: string | null
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string | null
          id?: string
          reason: string
          ref_id?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string | null
          id?: string
          reason?: string
          ref_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      daily_quests: {
        Row: {
          coin_reward: number | null
          description: string | null
          goal_type: string | null
          goal_value: number | null
          id: string
          name: string
          slug: string
          xp_reward: number | null
        }
        Insert: {
          coin_reward?: number | null
          description?: string | null
          goal_type?: string | null
          goal_value?: number | null
          id?: string
          name: string
          slug: string
          xp_reward?: number | null
        }
        Update: {
          coin_reward?: number | null
          description?: string | null
          goal_type?: string | null
          goal_value?: number | null
          id?: string
          name?: string
          slug?: string
          xp_reward?: number | null
        }
        Relationships: []
      }
      friend_requests: {
        Row: {
          created_at: string | null
          from_id: string
          id: string
          status: Database["public"]["Enums"]["friend_status"] | null
          to_id: string
        }
        Insert: {
          created_at?: string | null
          from_id: string
          id?: string
          status?: Database["public"]["Enums"]["friend_status"] | null
          to_id: string
        }
        Update: {
          created_at?: string | null
          from_id?: string
          id?: string
          status?: Database["public"]["Enums"]["friend_status"] | null
          to_id?: string
        }
        Relationships: []
      }
      friends: {
        Row: {
          created_at: string | null
          id: string
          user_a: string
          user_b: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          user_a: string
          user_b: string
        }
        Update: {
          created_at?: string | null
          id?: string
          user_a?: string
          user_b?: string
        }
        Relationships: []
      }
      house_items: {
        Row: {
          category: string | null
          emoji: string | null
          height: number | null
          id: string
          name: string
          price_coins: number | null
          slug: string
          width: number | null
        }
        Insert: {
          category?: string | null
          emoji?: string | null
          height?: number | null
          id?: string
          name: string
          price_coins?: number | null
          slug: string
          width?: number | null
        }
        Update: {
          category?: string | null
          emoji?: string | null
          height?: number | null
          id?: string
          name?: string
          price_coins?: number | null
          slug?: string
          width?: number | null
        }
        Relationships: []
      }
      house_likes: {
        Row: {
          created_at: string | null
          house_id: string
          id: string
          liker_id: string
        }
        Insert: {
          created_at?: string | null
          house_id: string
          id?: string
          liker_id: string
        }
        Update: {
          created_at?: string | null
          house_id?: string
          id?: string
          liker_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "house_likes_house_id_fkey"
            columns: ["house_id"]
            isOneToOne: false
            referencedRelation: "houses"
            referencedColumns: ["id"]
          },
        ]
      }
      house_placements: {
        Row: {
          house_id: string
          id: string
          item_id: string
          pos_x: number
          pos_y: number
          rotation: number | null
        }
        Insert: {
          house_id: string
          id?: string
          item_id: string
          pos_x: number
          pos_y: number
          rotation?: number | null
        }
        Update: {
          house_id?: string
          id?: string
          item_id?: string
          pos_x?: number
          pos_y?: number
          rotation?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "house_placements_house_id_fkey"
            columns: ["house_id"]
            isOneToOne: false
            referencedRelation: "houses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "house_placements_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "house_items"
            referencedColumns: ["id"]
          },
        ]
      }
      house_tiers: {
        Row: {
          bg_gradient: string | null
          description: string | null
          grid_h: number | null
          grid_w: number | null
          id: string
          name: string
          price_coins: number | null
          slug: string
          theme: string | null
        }
        Insert: {
          bg_gradient?: string | null
          description?: string | null
          grid_h?: number | null
          grid_w?: number | null
          id?: string
          name: string
          price_coins?: number | null
          slug: string
          theme?: string | null
        }
        Update: {
          bg_gradient?: string | null
          description?: string | null
          grid_h?: number | null
          grid_w?: number | null
          id?: string
          name?: string
          price_coins?: number | null
          slug?: string
          theme?: string | null
        }
        Relationships: []
      }
      houses: {
        Row: {
          created_at: string | null
          id: string
          name: string | null
          tier_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          name?: string | null
          tier_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          name?: string | null
          tier_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "houses_tier_id_fkey"
            columns: ["tier_id"]
            isOneToOne: false
            referencedRelation: "house_tiers"
            referencedColumns: ["id"]
          },
        ]
      }
      inventory: {
        Row: {
          acquired_at: string | null
          id: string
          item_id: string
          qty: number | null
          user_id: string
        }
        Insert: {
          acquired_at?: string | null
          id?: string
          item_id: string
          qty?: number | null
          user_id: string
        }
        Update: {
          acquired_at?: string | null
          id?: string
          item_id?: string
          qty?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "inventory_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "shop_items"
            referencedColumns: ["id"]
          },
        ]
      }
      matchmaking_queue: {
        Row: {
          id: string
          joined_at: string | null
          language: Database["public"]["Enums"]["code_language"] | null
          rank_tier: Database["public"]["Enums"]["rank_tier"]
          ranked: boolean | null
          user_id: string
        }
        Insert: {
          id?: string
          joined_at?: string | null
          language?: Database["public"]["Enums"]["code_language"] | null
          rank_tier: Database["public"]["Enums"]["rank_tier"]
          ranked?: boolean | null
          user_id: string
        }
        Update: {
          id?: string
          joined_at?: string | null
          language?: Database["public"]["Enums"]["code_language"] | null
          rank_tier?: Database["public"]["Enums"]["rank_tier"]
          ranked?: boolean | null
          user_id?: string
        }
        Relationships: []
      }
      profile_likes: {
        Row: {
          created_at: string | null
          id: string
          liker_id: string
          profile_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          liker_id: string
          profile_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          liker_id?: string
          profile_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_likes_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          ban_reason: string | null
          banned: boolean | null
          best_streak: number | null
          bio: string | null
          coins: number | null
          country_code: string | null
          created_at: string | null
          current_streak: number | null
          display_name: string | null
          draws: number | null
          equipped_character_id: string | null
          equipped_frame: string | null
          gems: number | null
          id: string
          last_login_date: string | null
          level: number | null
          light_mode: boolean | null
          losses: number | null
          rank_points: number | null
          rank_tier: Database["public"]["Enums"]["rank_tier"] | null
          referral_code: string | null
          referred_by: string | null
          theme: Database["public"]["Enums"]["theme_name"] | null
          total_passed: number | null
          total_submissions: number | null
          updated_at: string | null
          username: string
          wins: number | null
          xp: number | null
        }
        Insert: {
          avatar_url?: string | null
          ban_reason?: string | null
          banned?: boolean | null
          best_streak?: number | null
          bio?: string | null
          coins?: number | null
          country_code?: string | null
          created_at?: string | null
          current_streak?: number | null
          display_name?: string | null
          draws?: number | null
          equipped_character_id?: string | null
          equipped_frame?: string | null
          gems?: number | null
          id: string
          last_login_date?: string | null
          level?: number | null
          light_mode?: boolean | null
          losses?: number | null
          rank_points?: number | null
          rank_tier?: Database["public"]["Enums"]["rank_tier"] | null
          referral_code?: string | null
          referred_by?: string | null
          theme?: Database["public"]["Enums"]["theme_name"] | null
          total_passed?: number | null
          total_submissions?: number | null
          updated_at?: string | null
          username: string
          wins?: number | null
          xp?: number | null
        }
        Update: {
          avatar_url?: string | null
          ban_reason?: string | null
          banned?: boolean | null
          best_streak?: number | null
          bio?: string | null
          coins?: number | null
          country_code?: string | null
          created_at?: string | null
          current_streak?: number | null
          display_name?: string | null
          draws?: number | null
          equipped_character_id?: string | null
          equipped_frame?: string | null
          gems?: number | null
          id?: string
          last_login_date?: string | null
          level?: number | null
          light_mode?: boolean | null
          losses?: number | null
          rank_points?: number | null
          rank_tier?: Database["public"]["Enums"]["rank_tier"] | null
          referral_code?: string | null
          referred_by?: string | null
          theme?: Database["public"]["Enums"]["theme_name"] | null
          total_passed?: number | null
          total_submissions?: number | null
          updated_at?: string | null
          username?: string
          wins?: number | null
          xp?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_referred_by_fkey"
            columns: ["referred_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      purchases: {
        Row: {
          created_at: string | null
          id: string
          item_id: string
          qty: number | null
          total_coins: number | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          item_id: string
          qty?: number | null
          total_coins?: number | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          item_id?: string
          qty?: number | null
          total_coins?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "purchases_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "shop_items"
            referencedColumns: ["id"]
          },
        ]
      }
      rank_history: {
        Row: {
          created_at: string | null
          delta: number
          id: string
          new_points: number
          new_tier: Database["public"]["Enums"]["rank_tier"]
          reason: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          delta: number
          id?: string
          new_points: number
          new_tier: Database["public"]["Enums"]["rank_tier"]
          reason?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          delta?: number
          id?: string
          new_points?: number
          new_tier?: Database["public"]["Enums"]["rank_tier"]
          reason?: string | null
          user_id?: string
        }
        Relationships: []
      }
      reserved_admins: {
        Row: {
          role: Database["public"]["Enums"]["app_role"]
          username: string
        }
        Insert: {
          role: Database["public"]["Enums"]["app_role"]
          username: string
        }
        Update: {
          role?: Database["public"]["Enums"]["app_role"]
          username?: string
        }
        Relationships: []
      }
      shop_items: {
        Row: {
          active: boolean | null
          category: string | null
          consumable: boolean | null
          created_at: string | null
          description: string | null
          effect: Json | null
          icon: string | null
          id: string
          name: string
          price_coins: number
          price_gems: number
          rarity: string | null
          slug: string
        }
        Insert: {
          active?: boolean | null
          category?: string | null
          consumable?: boolean | null
          created_at?: string | null
          description?: string | null
          effect?: Json | null
          icon?: string | null
          id?: string
          name: string
          price_coins?: number
          price_gems?: number
          rarity?: string | null
          slug: string
        }
        Update: {
          active?: boolean | null
          category?: string | null
          consumable?: boolean | null
          created_at?: string | null
          description?: string | null
          effect?: Json | null
          icon?: string | null
          id?: string
          name?: string
          price_coins?: number
          price_gems?: number
          rarity?: string | null
          slug?: string
        }
        Relationships: []
      }
      spin_history: {
        Row: {
          amount: number | null
          created_at: string | null
          id: string
          reward: string
          user_id: string
        }
        Insert: {
          amount?: number | null
          created_at?: string | null
          id?: string
          reward: string
          user_id: string
        }
        Update: {
          amount?: number | null
          created_at?: string | null
          id?: string
          reward?: string
          user_id?: string
        }
        Relationships: []
      }
      submissions: {
        Row: {
          ai_feedback: string | null
          battle_id: string | null
          challenge_id: string
          code: string
          created_at: string | null
          id: string
          mode: string | null
          passed: boolean | null
          score: number | null
          time_taken_seconds: number | null
          user_id: string
        }
        Insert: {
          ai_feedback?: string | null
          battle_id?: string | null
          challenge_id: string
          code: string
          created_at?: string | null
          id?: string
          mode?: string | null
          passed?: boolean | null
          score?: number | null
          time_taken_seconds?: number | null
          user_id: string
        }
        Update: {
          ai_feedback?: string | null
          battle_id?: string | null
          challenge_id?: string
          code?: string
          created_at?: string | null
          id?: string
          mode?: string | null
          passed?: boolean | null
          score?: number | null
          time_taken_seconds?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "submissions_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "challenges"
            referencedColumns: ["id"]
          },
        ]
      }
      tournament_entries: {
        Row: {
          id: string
          rank: number | null
          score: number | null
          tournament_id: string
          user_id: string
        }
        Insert: {
          id?: string
          rank?: number | null
          score?: number | null
          tournament_id: string
          user_id: string
        }
        Update: {
          id?: string
          rank?: number | null
          score?: number | null
          tournament_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tournament_entries_tournament_id_fkey"
            columns: ["tournament_id"]
            isOneToOne: false
            referencedRelation: "tournaments"
            referencedColumns: ["id"]
          },
        ]
      }
      tournaments: {
        Row: {
          created_at: string | null
          description: string | null
          ends_at: string
          id: string
          language: Database["public"]["Enums"]["code_language"] | null
          name: string
          prize_pool: number | null
          starts_at: string
          status: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          ends_at: string
          id?: string
          language?: Database["public"]["Enums"]["code_language"] | null
          name: string
          prize_pool?: number | null
          starts_at: string
          status?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          ends_at?: string
          id?: string
          language?: Database["public"]["Enums"]["code_language"] | null
          name?: string
          prize_pool?: number | null
          starts_at?: string
          status?: string | null
        }
        Relationships: []
      }
      user_achievements: {
        Row: {
          achievement_id: string
          id: string
          unlocked_at: string | null
          user_id: string
        }
        Insert: {
          achievement_id: string
          id?: string
          unlocked_at?: string | null
          user_id: string
        }
        Update: {
          achievement_id?: string
          id?: string
          unlocked_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_achievements_achievement_id_fkey"
            columns: ["achievement_id"]
            isOneToOne: false
            referencedRelation: "achievements"
            referencedColumns: ["id"]
          },
        ]
      }
      user_characters: {
        Row: {
          character_id: string
          id: string
          unlocked_at: string | null
          user_id: string
        }
        Insert: {
          character_id: string
          id?: string
          unlocked_at?: string | null
          user_id: string
        }
        Update: {
          character_id?: string
          id?: string
          unlocked_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_characters_character_id_fkey"
            columns: ["character_id"]
            isOneToOne: false
            referencedRelation: "characters"
            referencedColumns: ["id"]
          },
        ]
      }
      user_quests: {
        Row: {
          claimed: boolean | null
          completed: boolean | null
          date: string | null
          id: string
          progress: number | null
          quest_id: string
          user_id: string
        }
        Insert: {
          claimed?: boolean | null
          completed?: boolean | null
          date?: string | null
          id?: string
          progress?: number | null
          quest_id: string
          user_id: string
        }
        Update: {
          claimed?: boolean | null
          completed?: boolean | null
          date?: string | null
          id?: string
          progress?: number | null
          quest_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_quests_quest_id_fkey"
            columns: ["quest_id"]
            isOneToOne: false
            referencedRelation: "daily_quests"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          granted_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          granted_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          granted_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      xp_ledger: {
        Row: {
          amount: number
          created_at: string | null
          id: string
          reason: string
          ref_id: string | null
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string | null
          id?: string
          reason: string
          ref_id?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string | null
          id?: string
          reason?: string
          ref_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      app_role: "user" | "moderator" | "admin" | "super_admin"
      battle_status: "waiting" | "active" | "finished" | "cancelled"
      code_language: "python" | "javascript" | "html" | "css" | "cpp" | "java"
      difficulty_tier:
        | "beginner"
        | "intermediate"
        | "advanced"
        | "expert"
        | "legendary"
      friend_status: "pending" | "accepted" | "blocked"
      rank_tier:
        | "bronze"
        | "silver"
        | "gold"
        | "platinum"
        | "diamond"
        | "master"
        | "grandmaster"
      theme_name: "neon" | "aurora" | "retro" | "minimal"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["user", "moderator", "admin", "super_admin"],
      battle_status: ["waiting", "active", "finished", "cancelled"],
      code_language: ["python", "javascript", "html", "css", "cpp", "java"],
      difficulty_tier: [
        "beginner",
        "intermediate",
        "advanced",
        "expert",
        "legendary",
      ],
      friend_status: ["pending", "accepted", "blocked"],
      rank_tier: [
        "bronze",
        "silver",
        "gold",
        "platinum",
        "diamond",
        "master",
        "grandmaster",
      ],
      theme_name: ["neon", "aurora", "retro", "minimal"],
    },
  },
} as const
