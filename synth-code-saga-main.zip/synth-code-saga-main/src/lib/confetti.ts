import confetti from "canvas-confetti";

export function fireConfetti() {
  const c1 = getComputedStyle(document.documentElement).getPropertyValue("--primary").trim();
  const c2 = getComputedStyle(document.documentElement).getPropertyValue("--secondary").trim();
  const c3 = getComputedStyle(document.documentElement).getPropertyValue("--gold").trim();
  const colors = [`hsl(${c1})`, `hsl(${c2})`, `hsl(${c3})`];
  confetti({ particleCount: 80, spread: 70, origin: { y: 0.7 }, colors });
  setTimeout(() => confetti({ particleCount: 60, angle: 60, spread: 55, origin: { x: 0 }, colors }), 200);
  setTimeout(() => confetti({ particleCount: 60, angle: 120, spread: 55, origin: { x: 1 }, colors }), 400);
}
