import { motion } from "framer-motion";
import { levelFromXp } from "@/lib/game";

export function XPBar({ xp, compact = false }: { xp: number; compact?: boolean }) {
  const { level, current, required } = levelFromXp(xp);
  const pct = Math.min(100, (current / required) * 100);
  return (
    <div className={compact ? "" : "space-y-1.5"}>
      {!compact && (
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold">
            Level <span className="grad-text font-bold text-base">{level}</span>
          </span>
          <span className="font-mono text-muted-foreground">
            {current} / {required} XP
          </span>
        </div>
      )}
      <div className="relative h-2.5 overflow-hidden rounded-full bg-muted">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="h-full grad-1 relative"
        >
          <div className="absolute inset-0 animate-shimmer" />
        </motion.div>
      </div>
    </div>
  );
}
