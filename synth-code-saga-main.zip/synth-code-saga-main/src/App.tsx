import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/lib/auth-context";
import { ThemeProvider } from "@/lib/theme-context";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Auth from "./pages/Auth";
import ResetPassword from "./pages/ResetPassword";
import Dashboard from "./pages/Dashboard";
import Learn from "./pages/Learn";
import ChallengePage from "./pages/Challenge";
import Battle from "./pages/Battle";
import Leaderboard from "./pages/Leaderboard";
import Shop from "./pages/Shop";
import Profile from "./pages/Profile";
import ProfileEdit from "./pages/ProfileEdit";
import { House, Characters, Friends, Quests, Spin, Tournaments, BattlePass, Admin } from "./pages/Stubs";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/learn" element={<Learn />} />
              <Route path="/learn/:language" element={<Learn />} />
              <Route path="/challenge/:id" element={<ChallengePage />} />
              <Route path="/battle" element={<Battle />} />
              <Route path="/leaderboard" element={<Leaderboard />} />
              <Route path="/shop" element={<Shop />} />
              <Route path="/house" element={<House />} />
              <Route path="/characters" element={<Characters />} />
              <Route path="/friends" element={<Friends />} />
              <Route path="/quests" element={<Quests />} />
              <Route path="/spin" element={<Spin />} />
              <Route path="/tournaments" element={<Tournaments />} />
              <Route path="/battle-pass" element={<BattlePass />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/profile/edit" element={<ProfileEdit />} />
              <Route path="/profile/:username" element={<Profile />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
