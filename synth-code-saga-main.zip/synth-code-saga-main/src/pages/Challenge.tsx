import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import Editor from "@monaco-editor/react";
import { AppLayout } from "@/components/AppLayout";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Clock, Coins, Send, Sparkles, AlertTriangle } from "lucide-react";
import { LANGUAGES, DIFFICULTIES, type Language, type Difficulty, levelFromXp } from "@/lib/game";
import { useAuth } from "@/lib/auth-context";
import { toast } from "sonner";
import { mascotSay } from "@/components/RobotMascot";
import { fireConfetti } from "@/lib/confetti";

type Challenge = {
  id: string; title: string; description: string; language: Language;
  difficulty: Difficulty; starter_code: string; expected_output: string | null;
  rubric: string | null; hints: string[]; time_limit_seconds: number;
  base_xp: number; base_coins: number;
};

const monacoLang = (l: Language) => l === "cpp" ? "cpp" : l === "java" ? "java" : l;

export default function ChallengePage() {
  const { id } = useParams<{ id: string }>();
  const [params] = useSearchParams();
  const mode = params.get("mode") === "practice" ? "practice" : "challenge";
  const navigate = useNavigate();
  const { user, profile, refreshProfile } = useAuth();
  const [challenge, setChallenge] = useState<Challenge | null>(null);
  const [code, setCode] = useState("");
  const [timeLeft, setTimeLeft] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ passed: boolean; score: number; feedback: string; xp: number; coins: number } | null>(null);
  const [warnings, setWarnings] = useState<string[]>([]);
  const startedAt = useRef<number>(Date.now());
  const lastKeyAt = useRef<number>(Date.now());

  useEffect(() => {
    if (!id) return;
    supabase.from("challenges").select("*").eq("id", id).maybeSingle().then(({ data }) => {
      if (!data) { toast.error("Challenge not found"); navigate("/learn"); return; }
      setChallenge(data as Challenge);
      setCode((data as Challenge).starter_code || "");
      if (mode === "challenge") setTimeLeft((data as Challenge).time_limit_seconds);
      startedAt.current = Date.now();
      mascotSay("thinking", "Read the brief carefully…");
    });
  }, [id, mode, navigate]);

  // Timer
  useEffect(() => {
    if (mode !== "challenge" || !challenge || result) return;
    if (timeLeft <= 0 && challenge) {
      handleTimeout();
      return;
    }
    const t = setInterval(() => setTimeLeft((v) => Math.max(0, v - 1)), 1000);
    return () => clearInterval(t);
  }, [timeLeft, mode, challenge, result]);

  // Anti-cheat: paste blocker, tab switch, AFK
  useEffect(() => {
    if (mode !== "challenge") return;
    const onVis = async () => {
      if (document.hidden && user && challenge) {
        setWarnings((w) => [...w, "Tab switch detected"]);
        await supabase.from("cheat_events").insert({
          user_id: user.id, event_type: "tab_switch", severity: 2, challenge_id: challenge.id,
        });
        mascotSay("shocked", "Don't leave the arena!");
      }
    };
    const onKey = () => { lastKeyAt.current = Date.now(); };
    document.addEventListener("visibilitychange", onVis);
    document.addEventListener("keydown", onKey);
    const afk = setInterval(() => {
      if (Date.now() - lastKeyAt.current > 60000 && user && challenge) {
        setWarnings((w) => [...w, "AFK detected"]);
        supabase.from("cheat_events").insert({
          user_id: user.id, event_type: "afk", severity: 1, challenge_id: challenge.id,
        });
        lastKeyAt.current = Date.now();
      }
    }, 30000);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      document.removeEventListener("keydown", onKey);
      clearInterval(afk);
    };
  }, [mode, user, challenge]);

  const handlePaste = async (e: React.ClipboardEvent) => {
    if (mode !== "challenge") return;
    const text = e.clipboardData.getData("text");
    if (text.length > 40) {
      e.preventDefault();
      setWarnings((w) => [...w, `Blocked large paste (${text.length} chars)`]);
      mascotSay("shocked", "No big pastes — write it yourself!");
      if (user && challenge) {
        await supabase.from("cheat_events").insert({
          user_id: user.id, event_type: "large_paste", severity: 3,
          details: { length: text.length }, challenge_id: challenge.id,
        });
      }
    }
  };

  const handleTimeout = async () => {
    if (!challenge || !user || result) return;
    setResult({ passed: false, score: 0, feedback: "Time's up! No rewards this run.", xp: 0, coins: 0 });
    mascotSay("shocked", "Time's up! Try again.");
    await supabase.from("submissions").insert({
      user_id: user.id, challenge_id: challenge.id, code, passed: false, score: 0,
      time_taken_seconds: challenge.time_limit_seconds, mode, ai_feedback: "Timeout",
    });
  };

  const submit = async () => {
    if (!challenge || !user) return;
    setSubmitting(true);
    mascotSay("thinking", "Judging your code…");
    try {
      const { data, error } = await supabase.functions.invoke("judge-submission", {
        body: { challenge_id: challenge.id, code, mode, time_taken: Math.floor((Date.now() - startedAt.current) / 1000) },
      });
      if (error) throw error;
      const r = data as { passed: boolean; score: number; feedback: string; xp_awarded: number; coins_awarded: number };
      setResult({ passed: r.passed, score: r.score, feedback: r.feedback, xp: r.xp_awarded, coins: r.coins_awarded });
      if (r.passed) { fireConfetti(); mascotSay("celebrate", `+${r.xp_awarded} XP, +${r.coins_awarded} 🪙!`); }
      else mascotSay("shocked", "Almost! Try again.");
      await refreshProfile();
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Submission failed";
      toast.error(msg);
      mascotSay("shocked", "Something broke. Retry?");
    } finally {
      setSubmitting(false);
    }
  };

  if (!challenge) {
    return <AppLayout><div className="text-center py-12 text-muted-foreground">Loading…</div></AppLayout>;
  }
  const d = DIFFICULTIES.find((x) => x.id === challenge.difficulty)!;
  const lang = LANGUAGES.find((x) => x.id === challenge.language)!;
  const mins = Math.floor(timeLeft / 60), secs = timeLeft % 60;

  return (
    <AppLayout>
      <div className="grid gap-4 lg:grid-cols-[380px_1fr]">
        <aside className="glass rounded-2xl p-5 h-fit lg:sticky lg:top-24">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-semibold">{lang.emoji} {lang.label}</span>
            <span className={`font-bold capitalize ${d.color}`}>{d.label}</span>
          </div>
          <h1 className="text-2xl font-extrabold">{challenge.title}</h1>
          <p className="mt-2 text-sm text-muted-foreground whitespace-pre-wrap">{challenge.description}</p>
          {challenge.expected_output && (
            <div className="mt-3">
              <div className="text-xs uppercase text-muted-foreground mb-1">Expected output</div>
              <pre className="font-mono text-xs bg-muted/50 rounded p-2 whitespace-pre-wrap">{challenge.expected_output}</pre>
            </div>
          )}
          <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
            <div className="glass rounded-lg p-2"><div className="text-xp font-bold">{challenge.base_xp}</div><div className="text-muted-foreground">XP</div></div>
            <div className="glass rounded-lg p-2"><div className="text-coin font-bold">{challenge.base_coins}</div><div className="text-muted-foreground">Coins</div></div>
            <div className="glass rounded-lg p-2"><div className="font-bold">{Math.round(challenge.time_limit_seconds / 60)}m</div><div className="text-muted-foreground">Limit</div></div>
          </div>
          {warnings.length > 0 && (
            <div className="mt-3 rounded-lg border border-warning/40 bg-warning/10 p-2 text-xs text-warning">
              <AlertTriangle className="inline h-3 w-3 mr-1" /> {warnings.length} warning(s) logged
            </div>
          )}
        </aside>

        <div>
          {mode === "challenge" && !result && (
            <div className={`mb-3 glass rounded-xl px-4 py-2 flex items-center justify-between ${timeLeft < 30 ? "border-destructive border-2 animate-glow-pulse" : ""}`}>
              <span className="flex items-center gap-2 text-sm font-semibold"><Clock className="h-4 w-4" /> Time left</span>
              <span className="font-mono text-2xl font-bold tabular-nums">{mins}:{String(secs).padStart(2, "0")}</span>
            </div>
          )}

          <div className="glass rounded-2xl overflow-hidden" onPasteCapture={handlePaste}>
            <Editor
              height="60vh"
              language={monacoLang(challenge.language)}
              theme="vs-dark"
              value={code}
              onChange={(v) => setCode(v ?? "")}
              options={{
                fontSize: 14,
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                fontFamily: "JetBrains Mono, monospace",
                automaticLayout: true,
              }}
            />
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            <Button onClick={submit} disabled={submitting || !!result} className="grad-1 border-0 text-primary-foreground glow">
              <Send className="h-4 w-4" /> {submitting ? "Judging…" : "Submit"}
            </Button>
            <Button variant="outline" onClick={() => navigate("/learn")}>Quit</Button>
          </div>

          {result && (
            <div className={`mt-4 glass rounded-2xl p-5 ${result.passed ? "neon-border" : ""}`}>
              <div className="flex items-center justify-between">
                <div className={`text-2xl font-extrabold ${result.passed ? "grad-text" : "text-destructive"}`}>
                  {result.passed ? "✅ Passed!" : "❌ Not yet"}
                </div>
                <div className="text-sm text-muted-foreground">Score: {result.score}/100</div>
              </div>
              <p className="mt-2 text-sm">{result.feedback}</p>
              {result.passed && (
                <div className="mt-3 flex gap-3 text-sm">
                  <span className="inline-flex items-center gap-1 text-xp"><Sparkles className="h-4 w-4" /> +{result.xp} XP</span>
                  <span className="inline-flex items-center gap-1 text-coin"><Coins className="h-4 w-4" /> +{result.coins}</span>
                </div>
              )}
              <div className="mt-4 flex gap-2">
                <Button onClick={() => navigate(`/learn/${challenge.language}`)} variant="outline">More challenges</Button>
                <Button onClick={() => window.location.reload()} className="grad-1 border-0 text-primary-foreground">Try again</Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
