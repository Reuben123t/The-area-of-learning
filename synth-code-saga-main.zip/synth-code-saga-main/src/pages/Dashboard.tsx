import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { AppLayout } from "@/components/AppLayout";
import { XPBar } from "@/components/XPBar";
import { RankBadge } from "@/components/RankBadge";
import { Button } from "@/components/ui/button";
import { LANGUAGES, levelFromXp, type RankTier } from "@/lib/game";
import { Coins, Flame, Swords, Trophy, Sparkles, Home as HomeIcon, ShoppingBag, Target, Gift } from "lucide-react";
import { mascotSay } from "@/components/RobotMascot";

export default function Dashboard() {
  const { profile, refreshProfile } = useAuth();
  const [stats, setStats] = useState({ challenges: 0, players: 0 });

  useEffect(() => {
    (async () => {
      const [{ count: c }, { count: p }] = await Promise.all([
        supabase.from("challenges").select("*", { count: "exact", head: true }),
        supabase.from("profiles").select("*", { count: "exact", head: true }),
      ]);
      setStats({ challenges: c ?? 0, players: p ?? 0 });
      // Mark login streak
      if (profile) {
        const today = new Date().toISOString().slice(0, 10);
        if (profile.current_streak === 0 || (profile as any).last_login_date !== today) {
          // Best-effort, ignore errors
          await supabase
            .from("profiles")
            .update({
              last_login_date: today,
              current_streak: profile.current_streak + (profile.current_streak === 0 ? 1 : 0),
            })
            .eq("id", profile.id);
          await refreshProfile();
        }
      }
      mascotSay("happy", "Welcome back to the arena!");
    })();
  }, []);

  if (!profile) return null;
  const lvl = levelFromXp(profile.xp);

  const tiles = [
    { to: "/learn", icon: Sparkles, label: "Practice", desc: "Untimed lessons", color: "from-cyan-500 to-blue-500" },
    { to: "/battle", icon: Swords, label: "Battle 1v1", desc: "Live ranked match", color: "from-pink-500 to-purple-500" },
    { to: "/leaderboard", icon: Trophy, label: "Leaderboard", desc: "Top coders", color: "from-amber-400 to-orange-500" },
    { to: "/shop", icon: ShoppingBag, label: "Shop", desc: "Spend coins", color: "from-emerald-500 to-teal-500" },
    { to: "/house", icon: HomeIcon, label: "Your House", desc: "Decorate & flex", color: "from-indigo-500 to-purple-600" },
    { to: "/quests", icon: Target, label: "Daily Quests", desc: "3 fresh today", color: "from-rose-500 to-red-600" },
    { to: "/spin", icon: Gift, label: "Spin Wheel", desc: "Free daily spin", color: "from-fuchsia-500 to-pink-600" },
    { to: "/battle-pass", icon: Flame, label: "Battle Pass", desc: "Season 1", color: "from-orange-500 to-red-500" },
  ];

  return (
    <AppLayout>
      {/* Hero status */}
      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass scanlines relative overflow-hidden rounded-2xl p-6 md:p-8 neon-border"
      >
        <div className="absolute inset-0 opacity-40" style={{ background: "var(--grad-hero)" }} />
        <div className="relative z-10 grid gap-6 md:grid-cols-[auto_1fr_auto] md:items-center">
          <div className="flex items-center gap-4">
            <div className="grid h-16 w-16 place-items-center rounded-2xl grad-1 text-primary-foreground text-2xl font-bold">
              {profile.username.slice(0, 1).toUpperCase()}
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Welcome back</div>
              <div className="text-2xl font-extrabold">{profile.display_name || profile.username}</div>
              <div className="mt-1 flex items-center gap-2">
                <RankBadge tier={profile.rank_tier as RankTier} points={profile.rank_points} />
                {profile.current_streak > 0 && (
                  <span className="inline-flex items-center gap-1 rounded-full glass px-2 py-0.5 text-xs">
                    <Flame className="h-3 w-3 text-warning" /> {profile.current_streak}d streak
                  </span>
                )}
              </div>
            </div>
          </div>

          <div>
            <XPBar xp={profile.xp} />
            <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
              <div className="glass rounded-lg p-2">
                <div className="text-coin text-base font-bold inline-flex items-center gap-1"><Coins className="h-4 w-4" /> {profile.coins}</div>
                <div className="text-muted-foreground">Coins</div>
              </div>
              <div className="glass rounded-lg p-2">
                <div className="text-success text-base font-bold">{profile.wins}</div>
                <div className="text-muted-foreground">Wins</div>
              </div>
              <div className="glass rounded-lg p-2">
                <div className="text-primary text-base font-bold">{profile.total_passed}</div>
                <div className="text-muted-foreground">Solved</div>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <Button asChild size="lg" className="grad-1 border-0 text-primary-foreground glow">
              <Link to="/battle">Quick Battle ⚔️</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/learn">Practice</Link>
            </Button>
          </div>
        </div>
      </motion.section>

      {/* Quick tiles */}
      <section className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {tiles.map((t, i) => (
          <motion.div
            key={t.to}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
          >
            <Link to={t.to} className="block glass hover-lift rounded-2xl p-4 h-full">
              <div className={`mb-3 grid h-10 w-10 place-items-center rounded-lg bg-gradient-to-br ${t.color} text-white`}>
                <t.icon className="h-5 w-5" />
              </div>
              <div className="font-bold">{t.label}</div>
              <div className="text-xs text-muted-foreground">{t.desc}</div>
            </Link>
          </motion.div>
        ))}
      </section>

      {/* Languages */}
      <section className="mt-8">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="text-xl font-bold">Pick your language</h2>
          <Link to="/learn" className="text-xs text-muted-foreground hover:text-foreground">All languages →</Link>
        </div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
          {LANGUAGES.map((l) => (
            <Link key={l.id} to={`/learn/${l.id}`} className="glass hover-lift rounded-xl p-4 text-center">
              <div className="text-3xl">{l.emoji}</div>
              <div className="mt-2 font-semibold">{l.label}</div>
            </Link>
          ))}
        </div>
      </section>

      {/* Footer stats */}
      <section className="mt-8 grid gap-3 md:grid-cols-3">
        <div className="glass rounded-xl p-4 text-center">
          <div className="text-2xl font-bold grad-text">{stats.challenges}</div>
          <div className="text-xs text-muted-foreground">Challenges live</div>
        </div>
        <div className="glass rounded-xl p-4 text-center">
          <div className="text-2xl font-bold grad-text">{stats.players}</div>
          <div className="text-xs text-muted-foreground">Coders in arena</div>
        </div>
        <div className="glass rounded-xl p-4 text-center">
          <div className="text-2xl font-bold grad-text">Lv {lvl.level}</div>
          <div className="text-xs text-muted-foreground">Your level</div>
        </div>
      </section>
    </AppLayout>
  );
}
