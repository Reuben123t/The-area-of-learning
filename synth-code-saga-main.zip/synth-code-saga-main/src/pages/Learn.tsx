import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { AppLayout } from "@/components/AppLayout";
import { supabase } from "@/integrations/supabase/client";
import { LANGUAGES, DIFFICULTIES, type Language, type Difficulty } from "@/lib/game";
import { Button } from "@/components/ui/button";
import { Clock, Coins, Sparkles } from "lucide-react";

type Challenge = {
  id: string;
  title: string;
  description: string;
  language: Language;
  difficulty: Difficulty;
  base_xp: number;
  base_coins: number;
  time_limit_seconds: number;
};

export default function Learn() {
  const { language } = useParams<{ language?: Language }>();
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [filterDiff, setFilterDiff] = useState<Difficulty | "all">("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    let q = supabase.from("challenges").select("*").eq("active", true).order("difficulty", { ascending: true });
    if (language) q = q.eq("language", language);
    q.then(({ data }) => {
      setChallenges((data ?? []) as Challenge[]);
      setLoading(false);
    });
  }, [language]);

  const visible = filterDiff === "all" ? challenges : challenges.filter((c) => c.difficulty === filterDiff);

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-extrabold tracking-tight">
          {language ? `${LANGUAGES.find((l) => l.id === language)?.emoji} ${LANGUAGES.find((l) => l.id === language)?.label}` : "Learn"}
        </h1>
        <p className="text-sm text-muted-foreground">Pick a challenge. Practice mode is untimed; Challenge mode rewards speed.</p>
      </div>

      {!language && (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6 mb-6">
          {LANGUAGES.map((l) => (
            <Link key={l.id} to={`/learn/${l.id}`} className="glass hover-lift rounded-xl p-4 text-center">
              <div className="text-3xl">{l.emoji}</div>
              <div className="mt-2 font-semibold">{l.label}</div>
            </Link>
          ))}
        </div>
      )}

      <div className="mb-4 flex flex-wrap gap-2">
        <button
          onClick={() => setFilterDiff("all")}
          className={`rounded-full px-3 py-1 text-xs font-semibold ${filterDiff === "all" ? "grad-1 text-primary-foreground" : "glass"}`}
        >
          All
        </button>
        {DIFFICULTIES.map((d) => (
          <button
            key={d.id}
            onClick={() => setFilterDiff(d.id)}
            className={`rounded-full px-3 py-1 text-xs font-semibold capitalize ${filterDiff === d.id ? "grad-1 text-primary-foreground" : "glass"} ${d.color}`}
          >
            {d.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center text-muted-foreground py-12">Loading challenges…</div>
      ) : visible.length === 0 ? (
        <div className="text-center text-muted-foreground py-12">No challenges yet for this filter.</div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {visible.map((c) => {
            const d = DIFFICULTIES.find((x) => x.id === c.difficulty)!;
            const lang = LANGUAGES.find((x) => x.id === c.language)!;
            return (
              <div key={c.id} className="glass hover-lift rounded-2xl p-5 flex flex-col">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-semibold">{lang.emoji} {lang.label}</span>
                  <span className={`font-bold capitalize ${d.color}`}>{d.label}</span>
                </div>
                <h3 className="font-bold text-lg leading-tight">{c.title}</h3>
                <p className="text-sm text-muted-foreground mt-1 line-clamp-2 flex-1">{c.description}</p>
                <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{Math.round(c.time_limit_seconds / 60)}m</span>
                  <span className="flex items-center gap-1 text-xp"><Sparkles className="h-3 w-3" />{c.base_xp} XP</span>
                  <span className="flex items-center gap-1 text-coin"><Coins className="h-3 w-3" />{c.base_coins}</span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <Button asChild size="sm" variant="outline">
                    <Link to={`/challenge/${c.id}?mode=practice`}>Practice</Link>
                  </Button>
                  <Button asChild size="sm" className="grad-1 border-0 text-primary-foreground">
                    <Link to={`/challenge/${c.id}?mode=challenge`}>Challenge</Link>
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </AppLayout>
  );
}
