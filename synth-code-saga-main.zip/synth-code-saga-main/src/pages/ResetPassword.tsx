import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ParticleBackground } from "@/components/ParticleBackground";

export default function ResetPassword() {
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Supabase puts type=recovery in the URL hash
    if (window.location.hash.includes("type=recovery") || window.location.hash.includes("access_token")) {
      setReady(true);
    } else {
      setReady(true);
    }
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) toast.error(error.message);
    else {
      toast.success("Password updated!");
      navigate("/dashboard");
    }
  };

  return (
    <div className="relative min-h-screen grid place-items-center p-6">
      <ParticleBackground />
      <form onSubmit={submit} className="glass w-full max-w-sm rounded-2xl p-8 space-y-4">
        <h1 className="text-2xl font-bold">Set a new password</h1>
        <div className="space-y-1.5">
          <Label htmlFor="pw">New password</Label>
          <Input id="pw" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} />
        </div>
        <Button type="submit" disabled={busy || !ready} className="w-full grad-1 text-primary-foreground border-0 glow">
          {busy ? "Saving..." : "Update password"}
        </Button>
      </form>
    </div>
  );
}
