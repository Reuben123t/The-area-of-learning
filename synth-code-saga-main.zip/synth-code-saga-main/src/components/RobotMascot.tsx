import { motion } from "framer-motion";
import { useEffect, useState } from "react";

export type MascotState = "idle" | "thinking" | "happy" | "shocked" | "celebrate" | "thumbsup";

const eyes: Record<MascotState, string> = {
  idle: "● ●",
  thinking: "◔ ◔",
  happy: "^ ^",
  shocked: "○ ○",
  celebrate: "★ ★",
  thumbsup: "◕ ◕",
};
const mouths: Record<MascotState, string> = {
  idle: "—",
  thinking: "~",
  happy: "ᴗ",
  shocked: "○",
  celebrate: "▽",
  thumbsup: "ᴗ",
};

export function RobotMascot({
  state = "idle",
  size = 96,
  message,
}: {
  state?: MascotState;
  size?: number;
  message?: string;
}) {
  const [bubble, setBubble] = useState<string | undefined>(message);
  useEffect(() => {
    setBubble(message);
    if (message) {
      const t = setTimeout(() => setBubble(undefined), 4000);
      return () => clearTimeout(t);
    }
  }, [message]);

  return (
    <div className="relative inline-flex flex-col items-center">
      {bubble && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass mb-2 max-w-[220px] rounded-xl px-3 py-2 text-xs font-medium text-foreground"
        >
          {bubble}
        </motion.div>
      )}
      <motion.div
        animate={
          state === "celebrate"
            ? { rotate: [0, -8, 8, -8, 0], y: [0, -8, 0] }
            : state === "shocked"
              ? { y: [0, -12, 0] }
              : state === "thinking"
                ? { rotate: [0, 4, -4, 0] }
                : { y: [0, -4, 0] }
        }
        transition={{ duration: state === "celebrate" ? 0.6 : 2.4, repeat: Infinity }}
        className="relative"
        style={{ width: size, height: size }}
      >
        {/* Antenna */}
        <div
          className="absolute left-1/2 top-0 h-3 w-[2px] -translate-x-1/2 bg-primary"
          style={{ boxShadow: "0 0 8px hsl(var(--primary))" }}
        />
        <div
          className="absolute left-1/2 top-[-6px] h-2 w-2 -translate-x-1/2 rounded-full bg-primary glow"
        />
        {/* Head */}
        <div
          className="glass relative mt-3 flex h-full w-full flex-col items-center justify-center rounded-2xl border-2 neon-border"
          style={{ background: "var(--grad-1)" }}
        >
          <div className="font-mono text-base text-primary-foreground" aria-hidden>
            {eyes[state]}
          </div>
          <div className="-mt-1 font-mono text-sm text-primary-foreground" aria-hidden>
            {mouths[state]}
          </div>
        </div>
        {state === "thumbsup" && (
          <div className="absolute -right-2 bottom-2 text-xl">👍</div>
        )}
        {state === "celebrate" && (
          <div className="absolute -right-3 -top-3 text-xl animate-float">🎉</div>
        )}
      </motion.div>
    </div>
  );
}

// Floating mascot pinned to corner, listens to global events
export function FloatingMascot() {
  const [state, setState] = useState<MascotState>("idle");
  const [msg, setMsg] = useState<string | undefined>();
  useEffect(() => {
    const handler = (e: Event) => {
      const ce = e as CustomEvent<{ state: MascotState; message?: string }>;
      setState(ce.detail.state);
      setMsg(ce.detail.message);
      if (ce.detail.state !== "idle") {
        setTimeout(() => setState("idle"), 4000);
      }
    };
    window.addEventListener("ca:mascot", handler as EventListener);
    return () => window.removeEventListener("ca:mascot", handler as EventListener);
  }, []);
  return (
    <div className="fixed bottom-4 right-4 z-50 hidden md:block">
      <RobotMascot state={state} size={84} message={msg} />
    </div>
  );
}

export function mascotSay(state: MascotState, message?: string) {
  window.dispatchEvent(new CustomEvent("ca:mascot", { detail: { state, message } }));
}
