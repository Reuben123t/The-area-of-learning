import { useEffect, useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Coins, Check } from "lucide-react";
import { toast } from "sonner";

type Item = { id: string; slug: string; name: string; description: string | null; category: string | null; price_coins: number; icon: string | null; rarity: string | null };

export default function Shop() {
  const { profile, refreshProfile } = useAuth();
  const [items, setItems] = useState<Item[]>([]);
  const [owned, setOwned] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    supabase.from("shop_items").select("*").eq("active", true).order("price_coins").then(({ data }) => setItems((data ?? []) as Item[]));
    if (profile) supabase.from("inventory").select("item_id").eq("user_id", profile.id).then(({ data }) => setOwned(new Set((data ?? []).map((x: any) => x.item_id))));
  }, [profile]);

  const buy = async (item: Item) => {
    if (!profile) return;
    if (profile.coins < item.price_coins) { toast.error("Not enough coins"); return; }
    setBusy(item.id);
    const { error } = await supabase.functions.invoke("shop-purchase", { body: { item_id: item.id } });
    setBusy(null);
    if (error) { toast.error(error.message); return; }
    toast.success(`Purchased ${item.name}!`);
    setOwned((s) => new Set([...s, item.id]));
    await refreshProfile();
  };

  return (
    <AppLayout>
      <div className="mb-6 flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-extrabold">Shop</h1>
          <p className="text-sm text-muted-foreground">Spend your coins on power-ups, cosmetics, and unlockables.</p>
        </div>
        <div className="glass rounded-full px-4 py-2 inline-flex items-center gap-2 text-coin font-bold">
          <Coins className="h-5 w-5" /> {profile?.coins ?? 0}
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((item) => {
          const isOwned = owned.has(item.id);
          return (
            <div key={item.id} className="glass hover-lift rounded-2xl p-5 flex flex-col">
              <div className="flex items-start justify-between">
                <div className="text-4xl">{item.icon}</div>
                <span className={`text-[10px] uppercase font-bold ${
                  item.rarity === "legendary" ? "text-warning" :
                  item.rarity === "epic" ? "text-secondary" :
                  item.rarity === "rare" ? "text-primary" : "text-muted-foreground"
                }`}>{item.rarity}</span>
              </div>
              <h3 className="mt-2 font-bold">{item.name}</h3>
              <p className="text-xs text-muted-foreground mt-1 line-clamp-2 flex-1">{item.description}</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="inline-flex items-center gap-1 text-coin font-bold"><Coins className="h-4 w-4" /> {item.price_coins}</span>
                {isOwned ? (
                  <span className="text-xs text-success inline-flex items-center gap-1"><Check className="h-3 w-3" /> Owned</span>
                ) : (
                  <Button size="sm" disabled={busy === item.id} onClick={() => buy(item)} className="grad-1 border-0 text-primary-foreground">
                    {busy === item.id ? "..." : "Buy"}
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </AppLayout>
  );
}
