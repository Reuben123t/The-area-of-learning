import { RANK_TIERS, type RankTier } from "@/lib/game";

const ICONS: Record<RankTier, string> = {
  bronze: "🥉",
  silver: "🥈",
  gold: "🥇",
  platinum: "💠",
  diamond: "💎",
  master: "🏆",
  grandmaster: "👑",
};

export function RankBadge({ tier, points }: { tier: RankTier; points?: number }) {
  const r = RANK_TIERS.find((x) => x.id === tier)!;
  return (
    <div className="inline-flex items-center gap-2 rounded-full glass px-3 py-1">
      <span className="text-base">{ICONS[tier]}</span>
      <div className="leading-tight">
        <div className={`text-xs font-bold ${r.color}`}>{r.label}</div>
        {points !== undefined && (
          <div className="text-[10px] font-mono text-muted-foreground">{points} RP</div>
        )}
      </div>
    </div>
  );
}
