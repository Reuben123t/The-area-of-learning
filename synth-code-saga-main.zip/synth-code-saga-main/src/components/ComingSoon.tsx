import { AppLayout } from "@/components/AppLayout";
import { ReactNode } from "react";

export function ComingSoon({ title, desc, children }: { title: string; desc: string; children?: ReactNode }) {
  return (
    <AppLayout>
      <div className="glass scanlines relative overflow-hidden rounded-2xl p-10 text-center neon-border">
        <div className="absolute inset-0 opacity-30" style={{ background: "var(--grad-hero)" }} />
        <div className="relative z-10">
          <div className="text-5xl mb-4">🚧</div>
          <h1 className="text-3xl font-extrabold grad-text">{title}</h1>
          <p className="mt-2 text-muted-foreground max-w-md mx-auto">{desc}</p>
          {children}
        </div>
      </div>
    </AppLayout>
  );
}
