import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth) return new Response(JSON.stringify({ error: "unauthenticated" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const userClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "unauthenticated" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const { item_id } = await req.json();
    if (!item_id) return new Response(JSON.stringify({ error: "bad input" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const { data: item } = await supabase.from("shop_items").select("*").eq("id", item_id).eq("active", true).maybeSingle();
    if (!item) return new Response(JSON.stringify({ error: "item not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const { data: prof } = await supabase.from("profiles").select("coins").eq("id", user.id).maybeSingle();
    if (!prof || prof.coins < item.price_coins) {
      return new Response(JSON.stringify({ error: "not enough coins" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    await supabase.from("profiles").update({ coins: prof.coins - item.price_coins }).eq("id", user.id);
    await supabase.from("coin_ledger").insert({ user_id: user.id, amount: -item.price_coins, reason: "shop_purchase", ref_id: item_id });
    await supabase.from("purchases").insert({ user_id: user.id, item_id, qty: 1, total_coins: item.price_coins });

    const { data: existing } = await supabase.from("inventory").select("id,qty").eq("user_id", user.id).eq("item_id", item_id).maybeSingle();
    if (existing) await supabase.from("inventory").update({ qty: existing.qty + 1 }).eq("id", existing.id);
    else await supabase.from("inventory").insert({ user_id: user.id, item_id, qty: 1 });

    return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "unknown" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
