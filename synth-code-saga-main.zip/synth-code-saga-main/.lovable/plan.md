# CodeArena — Gamified Coding Platform (Kitchen-Sink v1)

A futuristic neon coding playground that fuses **Cyberpunk neon + Glassmorphism aurora + Retro arcade + Minimal dark gaming** into one switchable design system. Users learn 6 languages, fight ranked 1v1 battles, customize avatars/houses/characters, earn coins, and level up — guided by an animated robot mascot and Lovable AI.

> **Reality check:** This is a massive scope. v1 will scaffold every system end-to-end with real working flows, but expect to iterate on polish, balance, and depth across follow-up requests. Think of v1 as the playable foundation of a billion-dollar product, not the final release.

---

## 🎨 Design system — "Quad-Aesthetic" theme engine

A single semantic token system with **4 swappable themes** (user picks in profile, all use the same component library):
- **Neon Cyberpunk** — deep black, electric cyan + magenta, glitch headings, scanline overlays
- **Aurora Glass** — frosted cards, purple/blue gradients, particle backgrounds, soft glows
- **Retro Arcade** — pixel font headings, CRT scanlines, bright primaries, 8-bit accents
- **Minimal Dark** — Linear-style clean dark, single accent, subtle motion

Plus a **Light mode** variant of each. Built in `index.css` as HSL tokens + Tailwind config, with custom keyframes (fade-in, scale-in, glow-pulse, glitch, particle-drift, neon-flicker), glassmorphism utilities, and a global particle background canvas.

Reusable building blocks: `GlassCard`, `NeonButton`, `XPBar`, `CoinPill`, `RankBadge`, `Avatar`, `LevelChip`, `ChallengeCard`, `Leaderboard`, `RobotMascot`, `ConfettiBurst`.

---

## 🔐 Auth & roles

- **Lovable Cloud** auth: email/password with verification + Google OAuth
- `profiles` table auto-created on signup (username, display_name, bio, avatar_id, country_code, theme, equipped_character, equipped_frame, active_house_id, joined_at)
- **`user_roles` table** with enum `app_role` (`user`, `moderator`, `admin`, `super_admin`) — never on profiles
- `has_role()` security-definer function powers all RLS
- **Super admin `Coder_Master3012`** seeded via migration: row in `user_roles` with role `super_admin` linked by username. The actual auth account is created when that username first signs up — first-login claim flow promotes them. Password is set by the user (never hardcoded).
- `/auth` page (sign in / sign up / forgot password) and `/reset-password` page

---

## 🧑‍🚀 Profile & customization

`/profile/:username` — public profile with: avatar + frame, country flag, equipped character, level + XP bar, coin balance, rank tier badge, win rate, badges earned, recent battles, profile likes, "Add friend" button.

`/profile/edit` — edit bio, pick avatar (from unlocked set), frame, theme, character, country, social links.

---

## 🎮 Learning & challenges

**Languages:** Python, JavaScript, HTML, CSS, C++, Java (Monaco editor with per-language syntax highlighting).

**Difficulty tiers:** Beginner → Intermediate → Advanced → Expert → Legendary, each with infinite procedurally-served levels (challenges tagged by tier; user progresses through them).

**Two modes:**
1. **Practice (untimed)** — learn freely, smaller XP/coin rewards, hints free
2. **Challenge (timed)** — full XP + coin + streak rewards; **zero rewards if timer hits 0**; jackpot bonus for perfect+fast solves

**Challenge content seeded** with ~40 starter challenges across languages/tiers (curated questions with expected outputs and rubrics). Schema supports unlimited admin-added challenges.

**Hybrid code validation (best of both):**
- Each challenge has an `expected_output` and a `rubric` (text)
- On submit: first run a fast string/regex match against expected output for deterministic pass/fail
- For open-ended challenges, fall back to **Lovable AI** (Gemini Flash) judging code against the rubric, returning `{passed, score, feedback}`
- This avoids needing Judge0 / Docker sandboxes while still feeling smart. Edge function `judge-submission` orchestrates it.

**Rewards engine** (`award-xp` edge function):
- XP scaled by difficulty × speed multiplier
- Coins on success, streak bonus (+10% per consecutive day, capped)
- Jackpot for perfect score under 50% of time
- Level-up triggers confetti + mascot celebration animation

---

## 🛡️ Anti-cheat layer

Client-side guards on challenge pages:
- Block paste of >40 chars into code editor (toast warning + flag)
- Track tab visibility (`document.visibilitychange`) → flag/auto-fail on repeat offenses
- Detect AFK (no keystrokes for X seconds in timed mode → auto-fail)
- Spam input detection (impossibly fast keystroke rate)
- Disable right-click + devtools shortcuts on battle pages (best-effort)

Server-side (`anti-cheat-log` edge function):
- Every flag logged to `cheat_events` table with severity
- Submissions also passed through AI similarity check vs known answers
- Repeat offenders auto-flagged in admin dashboard; admin can ban

---

## ⚔️ Real-time 1v1 battles

`/battle` lobby:
- **Quick match** → matchmaking queue based on rank tier
- **Friend invite** → invite code or friend list
- **Ranked ladder** toggle

Battle room (`/battle/:id`):
- Both players get the same challenge, synced timer, live opponent progress bar, mascot reactions
- Powered by **Supabase Realtime** (presence + broadcast) — no separate Socket.io server needed
- First correct submission wins instantly; if timer expires with both failing, it's a draw (no winner, no rewards)
- Winner gains rank points, loser loses some (ELO-style)

**Rank tiers:** Bronze → Silver → Gold → Platinum → Diamond → Master → Grandmaster, each with sub-divisions (III/II/I).

---

## 🏆 Leaderboards

`/leaderboard` with tabs: Most Coins · Highest XP · Fastest Solver · Best Streak · Highest Win Rate · (Clans — placeholder for v2). Filter by global / country / friends. Top 3 get glowing podium cards.

---

## 🤖 Robot mascot + AI assistant

**Mascot "Byte":** floating animated SVG/CSS robot bottom-right on every page. States: idle (breathing), thinking (gear spin), happy (bounce), shocked (jump), celebration (confetti), thumbs-up. Triggered by app events.

**AI Coach (drawer chat):** powered by Lovable AI (`google/gemini-3-flash-preview`) via `ai-coach` edge function with streaming SSE. Modes:
- Explain code · Fix my bug · Give a hint (limited per challenge — costs Hint Pack item) · Teach syntax · Generate practice quiz · Motivate me

System prompt enforces educational tone and **never gives full solutions during active timed challenges** (anti-cheat).

---

## 💰 Economy & shop

Coins earned from: wins, daily login (escalating streak rewards), achievements, referrals (unique code per user), tournament placements, daily quests, spin wheel.

`/shop` with categories. **12 launch items:**
1. Error Detector (one-time use, highlights syntax errors in next challenge)
2. Guess-the-Next-Word AI assist
3. Hint Pack (3 hints)
4. Time Freeze (+30s in next timed challenge)
5. Theme Pack (unlocks extra theme variants)
6. XP Booster (2× XP for 1 hour)
7. Avatar Frame (cosmetic)
8. Robot Skin (mascot reskin)
9. Lucky Chest (random reward)
10. Secret Character Unlock (random from locked pool)
11. Sound Pack (UI/victory sound themes)
12. Coin Doubler (24h)

Schema supports admin adding unlimited items.

---

## 🏠 Virtual house system

`/house` — buy a home with coins. Tiers: **Cyber loft, Space station, Hacker basement, Luxury penthouse**.
Each house is a 2D grid (CSS-based isometric-ish view) where users place purchased furniture: coding desk, monitor wall, trophy shelf, plants, posters, neon signs. Drag-and-drop placement saved to DB. Visit friends' houses via `/house/:username`. Profile likes are given by visitors.

---

## 🦸 Unlockable characters

5 characters purchasable with coins, each with idle + victory pose animations and emote set:
- Cyber Ninja · Robot Hacker · Code Wizard · Pixel Knight · Neon Samurai

Equipped character shows on profile, in battle room, and during victory screen.

---

## 🎯 Engagement systems

- **Daily quests** (3 per day, refresh at midnight UTC via cron edge function)
- **Daily login streak** with 7-day reward calendar
- **Spin wheel** (1 free spin/day, extra spins purchasable)
- **Achievements** (~30 seeded: First Win, 10-Win Streak, Polyglot, Night Owl, etc.) with badge display
- **Friends system** (request/accept/block)
- **Profile likes**
- **Live chat** — global + per-battle, moderated; Realtime channels
- **Battle replays** — store submission history; replay shows code + timing
- **Seasonal Battle Pass** — free + premium track, weekly XP target, 30 reward tiers per season
- **Weekly tournaments** — bracket auto-generated; coin pool prizes
- **Holiday events** — admin-toggled themes/challenges
- **AI personalized difficulty** — picks next practice challenge based on user's recent pass rate

---

## 🛠️ Admin dashboard `/admin` (super_admin + admin only)

Sidebar navigation, RLS-locked, every action audit-logged:
- **Users** — search, view, ban/unban, reset password trigger, impersonate (read-only mode toggle)
- **Cheat reports** — flagged events, severity, one-click ban
- **Economy** — adjust user coins/XP, reset season, view inflation stats
- **Challenges** — CRUD challenges, set difficulty/language/expected output/rubric
- **Tournaments** — create, set bracket, prize pool
- **Shop** — CRUD items, prices, stock
- **Announcements** — broadcast banner (Realtime push to all users)
- **Chat moderation** — message log, delete, mute users
- **Rewards** — grant items/coins to users
- **Logs** — submission, auth, cheat, admin action logs
- **Analytics** — DAU/MAU, signups chart, revenue (coin sinks/sources), top languages, retention cohorts

---

## 🗄️ Database schema (Lovable Cloud)

Core tables (all with RLS): `profiles`, `user_roles`, `challenges`, `submissions`, `cheat_events`, `xp_ledger`, `coin_ledger`, `achievements`, `user_achievements`, `inventory`, `shop_items`, `purchases`, `characters`, `user_characters`, `houses`, `house_items`, `house_placements`, `friends`, `friend_requests`, `chat_messages`, `battles`, `battle_participants`, `rank_history`, `leaderboards_cache`, `daily_quests`, `user_quests`, `login_streaks`, `spin_history`, `tournaments`, `tournament_entries`, `battle_pass_seasons`, `battle_pass_progress`, `announcements`, `audit_logs`, `referrals`.

Roles enforced via `has_role()`. Coin/XP mutations only via edge functions (server-side validation, no client write to ledgers).

---

## ⚡ Edge functions

- `judge-submission` — hybrid validator (expected-output + AI rubric)
- `award-xp` — server-validated XP/coin/streak math
- `ai-coach` — streaming Lovable AI chat
- `matchmaker` — finds 1v1 opponent in queue
- `daily-cron` — quests refresh, streak rollover, leaderboard cache (scheduled)
- `tournament-runner` — bracket advancement
- `anti-cheat-log` — receives client flags, scores severity
- `admin-action` — gated mutations (ban, grant, reset)
- `referral-claim` — apply referral codes

All public-facing functions: input validation with Zod, JWT validated in code, CORS headers, structured errors.

---

## 🗺️ Routes

`/` (landing with hero + live stats) · `/auth` · `/reset-password` · `/dashboard` · `/learn/:language` · `/challenge/:id` · `/practice` · `/battle` · `/battle/:id` · `/leaderboard` · `/shop` · `/house` · `/house/:username` · `/characters` · `/profile/:username` · `/profile/edit` · `/friends` · `/chat` · `/quests` · `/spin` · `/tournaments` · `/battle-pass` · `/admin/*`

---

## 📦 What ships in v1 build

Everything above is **scaffolded with working flows, real DB, real RLS, real auth, real AI, real Realtime, real anti-cheat, real admin tools, and real seed content**. Some areas (deep house decoration UX, full tournament bracket UI, character animations, sound packs) will be functional but minimal — ready for you to point at what to deepen next.

After you click Implement, expect this to take multiple build iterations — I'll start with foundation (design system + auth + profiles + DB schema + dashboard), then layer challenges, then battles, then shop/house/characters, then admin, then engagement systems. You'll see the app grow live.