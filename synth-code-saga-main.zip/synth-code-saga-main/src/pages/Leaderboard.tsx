import { useEffect, useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import { supabase } from "@/integrations/supabase/client";
import { Link } from "react-router-dom";
import { Trophy } from "lucide-react";

type Row = { id: string; username: string; xp: number; coins: number; wins: number; rank_tier: string; rank_points: number; current_streak: number };

export default function Leaderboard() {
  const [tab, setTab] = useState<"coins" | "xp" | "wins" | "streak" | "rank">("xp");
  const [rows, setRows] = useState<Row[]>([]);
  useEffect(() => {
    const col = tab === "coins" ? "coins" : tab === "wins" ? "wins" : tab === "streak" ? "best_streak" : tab === "rank" ? "rank_points" : "xp";
    supabase.from("profiles").select("id,username,xp,coins,wins,rank_tier,rank_points,current_streak,best_streak").order(col, { ascending: false }).limit(50).then(({ data }) => setRows((data ?? []) as any));
  }, [tab]);
  const tabs = [
    { id: "xp", label: "Highest XP" },
    { id: "coins", label: "Most Coins" },
    { id: "wins", label: "Most Wins" },
    { id: "streak", label: "Best Streak" },
    { id: "rank", label: "Rank Points" },
  ] as const;
  return (
    <AppLayout>
      <h1 className="text-3xl font-extrabold mb-2 inline-flex items-center gap-2"><Trophy className="text-gold" /> Leaderboard</h1>
      <div className="flex flex-wrap gap-2 mb-4">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`rounded-full px-3 py-1 text-xs font-semibold ${tab === t.id ? "grad-1 text-primary-foreground" : "glass"}`}>{t.label}</button>
        ))}
      </div>
      <div className="glass rounded-2xl overflow-hidden">
        {rows.map((r, i) => (
          <Link to={`/profile/${r.username}`} key={r.id} className="flex items-center gap-4 px-4 py-3 hover:bg-muted/40 border-b border-border/50 last:border-0">
            <div className={`w-8 text-center font-bold ${i === 0 ? "text-gold text-xl" : i === 1 ? "text-rank-silver" : i === 2 ? "text-rank-bronze" : "text-muted-foreground"}`}>
              {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `#${i + 1}`}
            </div>
            <div className="grid h-9 w-9 place-items-center rounded-full grad-1 font-bold text-primary-foreground">{r.username.slice(0, 1).toUpperCase()}</div>
            <div className="flex-1">
              <div className="font-semibold">{r.username}</div>
              <div className="text-xs text-muted-foreground capitalize">{r.rank_tier} · {r.rank_points} RP</div>
            </div>
            <div className="font-mono text-sm font-bold">
              {tab === "coins" ? `🪙 ${r.coins}` : tab === "wins" ? `⚔️ ${r.wins}` : tab === "streak" ? `🔥 ${r.current_streak}` : tab === "rank" ? `${r.rank_points} RP` : `✨ ${r.xp}`}
            </div>
          </Link>
        ))}
      </div>
    </AppLayout>
  );
}
