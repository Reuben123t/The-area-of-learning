import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { AppLayout } from "@/components/AppLayout";
import { supabase } from "@/integrations/supabase/client";
import { XPBar } from "@/components/XPBar";
import { RankBadge } from "@/components/RankBadge";
import { Heart, Coins, Flame, Trophy } from "lucide-react";
import type { RankTier } from "@/lib/game";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function Profile() {
  const { username } = useParams<{ username: string }>();
  const { user } = useAuth();
  const [p, setP] = useState<any>(null);
  const [likes, setLikes] = useState(0);
  const [liked, setLiked] = useState(false);
  useEffect(() => {
    if (!username) return;
    supabase.from("profiles").select("*").eq("username", username).maybeSingle().then(async ({ data }) => {
      setP(data);
      if (data) {
        const { count } = await supabase.from("profile_likes").select("*", { count: "exact", head: true }).eq("profile_id", data.id);
        setLikes(count ?? 0);
        if (user) {
          const { data: l } = await supabase.from("profile_likes").select("id").eq("profile_id", data.id).eq("liker_id", user.id).maybeSingle();
          setLiked(!!l);
        }
      }
    });
  }, [username, user]);
  const toggleLike = async () => {
    if (!user || !p) return;
    if (liked) { await supabase.from("profile_likes").delete().eq("profile_id", p.id).eq("liker_id", user.id); setLikes((n) => n - 1); setLiked(false); }
    else { const { error } = await supabase.from("profile_likes").insert({ profile_id: p.id, liker_id: user.id }); if (!error) { setLikes((n) => n + 1); setLiked(true); toast.success("Liked!"); } }
  };
  if (!p) return <AppLayout><div className="text-center py-12 text-muted-foreground">Loading…</div></AppLayout>;
  return (
    <AppLayout>
      <div className="glass scanlines relative overflow-hidden rounded-2xl p-6 md:p-8 neon-border">
        <div className="absolute inset-0 opacity-30" style={{ background: "var(--grad-hero)" }} />
        <div className="relative z-10 flex flex-col md:flex-row items-start gap-6">
          <div className="grid h-24 w-24 place-items-center rounded-2xl grad-1 text-3xl font-bold text-primary-foreground">{p.username[0].toUpperCase()}</div>
          <div className="flex-1">
            <div className="flex items-center gap-2"><h1 className="text-3xl font-extrabold">{p.display_name || p.username}</h1></div>
            <div className="text-sm text-muted-foreground">@{p.username} · {p.country_code}</div>
            <p className="mt-2 text-sm">{p.bio || <span className="text-muted-foreground italic">No bio yet</span>}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <RankBadge tier={p.rank_tier as RankTier} points={p.rank_points} />
              <span className="inline-flex items-center gap-1 rounded-full glass px-3 py-1 text-xs"><Trophy className="h-3 w-3 text-gold" /> {p.wins}W · {p.losses}L</span>
              <span className="inline-flex items-center gap-1 rounded-full glass px-3 py-1 text-xs"><Coins className="h-3 w-3 text-coin" /> {p.coins}</span>
              <span className="inline-flex items-center gap-1 rounded-full glass px-3 py-1 text-xs"><Flame className="h-3 w-3 text-warning" /> {p.current_streak}</span>
            </div>
            <div className="mt-4 max-w-md"><XPBar xp={p.xp} /></div>
          </div>
          {user && user.id !== p.id && (
            <Button onClick={toggleLike} variant={liked ? "default" : "outline"}><Heart className={`h-4 w-4 ${liked ? "fill-current" : ""}`} /> {likes}</Button>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
