import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ParticleBackground } from "@/components/ParticleBackground";
import { RobotMascot } from "@/components/RobotMascot";
import { LANGUAGES } from "@/lib/game";
import { useAuth } from "@/lib/auth-context";
import { Trophy, Swords, Sparkles, Home, Users, Zap } from "lucide-react";

const Index = () => {
  const { user } = useAuth();

  const features = [
    { icon: Swords, title: "1v1 Code Battles", desc: "Live matches, ranked ladder, instant victory for the first solver." },
    { icon: Trophy, title: "Climb 7 Tiers", desc: "Bronze to Grandmaster — earn RP and dominate the global leaderboard." },
    { icon: Sparkles, title: "AI Coach Byte", desc: "Explains code, fixes bugs, hints, and quizzes you on demand." },
    { icon: Home, title: "Your Crib", desc: "Buy houses with coins. Decorate. Invite friends to flex." },
    { icon: Users, title: "Friends & Guilds", desc: "Add friends, chat live, replay battles, climb together." },
    { icon: Zap, title: "Anti-cheat & Fair Play", desc: "Paste blockers, AFK detection, AI similarity checks." },
  ];

  return (
    <div className="relative min-h-screen overflow-hidden">
      <ParticleBackground density={70} />

      {/* Top bar */}
      <header className="container flex items-center justify-between py-6">
        <div className="flex items-center gap-2 font-bold">
          <div className="grid h-10 w-10 place-items-center rounded-lg grad-1 text-primary-foreground glow font-mono">
            {"</>"}
          </div>
          <span className="grad-text text-xl">CodeArena</span>
        </div>
        <div className="flex items-center gap-2">
          {user ? (
            <Button asChild className="grad-1 border-0 text-primary-foreground glow">
              <Link to="/dashboard">Open Arena</Link>
            </Button>
          ) : (
            <>
              <Button asChild variant="ghost" size="sm">
                <Link to="/auth">Sign in</Link>
              </Button>
              <Button asChild size="sm" className="grad-1 border-0 text-primary-foreground glow">
                <Link to="/auth?mode=signup">Join free</Link>
              </Button>
            </>
          )}
        </div>
      </header>

      {/* Hero */}
      <section className="container relative py-12 md:py-24">
        <div className="grid items-center gap-12 md:grid-cols-2">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="inline-flex items-center gap-2 rounded-full glass px-3 py-1 text-xs font-medium text-muted-foreground mb-6">
              <span className="h-2 w-2 rounded-full bg-success animate-glow-pulse" />
              Live multiplayer · 6 languages · AI-coached
            </div>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.05]">
              Code like a <span className="grad-text">gamer.</span>
              <br /> Level up like a <span className="grad-text">legend.</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-xl">
              CodeArena turns programming into a game you can&apos;t put down. Solve challenges,
              battle live opponents, earn coins, customize your house and characters, and climb
              the ranks from Bronze to Grandmaster.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg" className="grad-1 border-0 text-primary-foreground glow text-base h-12 px-6">
                <Link to={user ? "/dashboard" : "/auth?mode=signup"}>
                  {user ? "Continue your run →" : "Start free →"}
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="h-12 px-6 text-base">
                <Link to="/leaderboard">See leaderboard</Link>
              </Button>
            </div>
            <div className="mt-8 flex items-center gap-6 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-primary" /> 6 languages</span>
              <span className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-secondary" /> 5 difficulty tiers</span>
              <span className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-coin" /> Real rewards</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative"
          >
            <div className="glass scanlines relative aspect-square max-w-md mx-auto rounded-3xl p-8 overflow-hidden neon-border">
              <div className="absolute inset-0 grad-hero opacity-50" style={{ background: "var(--grad-hero)" }} />
              <div className="relative z-10 flex h-full flex-col items-center justify-center gap-4">
                <RobotMascot state="celebrate" size={140} />
                <div className="text-center">
                  <div className="font-mono text-xs text-muted-foreground">+ 250 XP · +120 🪙</div>
                  <div className="text-2xl font-bold grad-text mt-1">PERFECT SOLVE!</div>
                  <div className="text-xs text-muted-foreground">12.4s · jackpot bonus 🎉</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Languages */}
      <section className="container py-10">
        <h2 className="text-center text-sm font-medium uppercase tracking-widest text-muted-foreground mb-6">
          Master all six
        </h2>
        <div className="flex flex-wrap items-center justify-center gap-3">
          {LANGUAGES.map((l) => (
            <div key={l.id} className="glass hover-lift flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold">
              <span className="text-lg">{l.emoji}</span>
              {l.label}
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="container py-16">
        <div className="grid gap-4 md:grid-cols-3">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="glass hover-lift rounded-2xl p-6"
            >
              <div className="grid h-10 w-10 place-items-center rounded-lg grad-1 text-primary-foreground mb-4">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="font-bold mb-1">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container py-16">
        <div className="glass scanlines relative overflow-hidden rounded-3xl p-10 md:p-16 text-center neon-border">
          <div className="absolute inset-0 opacity-40" style={{ background: "var(--grad-hero)" }} />
          <div className="relative z-10">
            <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight">
              The arena is <span className="grad-text">open</span>.
            </h2>
            <p className="mt-3 text-muted-foreground max-w-xl mx-auto">
              Join the next generation of coders who learn by playing. No credit card. No setup.
            </p>
            <Button asChild size="lg" className="mt-6 grad-1 border-0 text-primary-foreground glow h-12 px-8 text-base">
              <Link to={user ? "/dashboard" : "/auth?mode=signup"}>
                {user ? "Open the arena" : "Create your account"}
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <footer className="container py-10 text-center text-xs text-muted-foreground">
        Built with ❤️ on Lovable Cloud · CodeArena © {new Date().getFullYear()}
      </footer>
    </div>
  );
};

export default Index;
