
-- =====================================================================
-- ENUMS
-- =====================================================================
CREATE TYPE public.app_role AS ENUM ('user', 'moderator', 'admin', 'super_admin');
CREATE TYPE public.difficulty_tier AS ENUM ('beginner', 'intermediate', 'advanced', 'expert', 'legendary');
CREATE TYPE public.code_language AS ENUM ('python', 'javascript', 'html', 'css', 'cpp', 'java');
CREATE TYPE public.rank_tier AS ENUM ('bronze', 'silver', 'gold', 'platinum', 'diamond', 'master', 'grandmaster');
CREATE TYPE public.battle_status AS ENUM ('waiting', 'active', 'finished', 'cancelled');
CREATE TYPE public.friend_status AS ENUM ('pending', 'accepted', 'blocked');
CREATE TYPE public.theme_name AS ENUM ('neon', 'aurora', 'retro', 'minimal');

-- =====================================================================
-- PROFILES
-- =====================================================================
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  display_name TEXT,
  bio TEXT DEFAULT '',
  avatar_url TEXT,
  country_code TEXT DEFAULT 'US',
  theme public.theme_name DEFAULT 'neon',
  light_mode BOOLEAN DEFAULT false,
  equipped_character_id UUID,
  equipped_frame TEXT,
  level INT DEFAULT 1,
  xp INT DEFAULT 0,
  coins INT DEFAULT 100,
  gems INT DEFAULT 0,
  current_streak INT DEFAULT 0,
  best_streak INT DEFAULT 0,
  last_login_date DATE,
  rank_tier public.rank_tier DEFAULT 'bronze',
  rank_points INT DEFAULT 0,
  wins INT DEFAULT 0,
  losses INT DEFAULT 0,
  draws INT DEFAULT 0,
  total_submissions INT DEFAULT 0,
  total_passed INT DEFAULT 0,
  banned BOOLEAN DEFAULT false,
  ban_reason TEXT,
  referral_code TEXT UNIQUE,
  referred_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- =====================================================================
-- USER ROLES (separate, secure)
-- =====================================================================
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  granted_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Reserved super admin username
CREATE TABLE public.reserved_admins (
  username TEXT PRIMARY KEY,
  role public.app_role NOT NULL
);
ALTER TABLE public.reserved_admins ENABLE ROW LEVEL SECURITY;
INSERT INTO public.reserved_admins (username, role) VALUES ('Coder_Master3012', 'super_admin');

-- has_role() — security definer to avoid recursion
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.is_admin(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role IN ('admin', 'super_admin')
  )
$$;

-- =====================================================================
-- AUTO-CREATE PROFILE + ASSIGN ROLE
-- =====================================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _username TEXT;
  _reserved_role public.app_role;
BEGIN
  _username := COALESCE(
    NEW.raw_user_meta_data->>'username',
    split_part(NEW.email, '@', 1) || substr(NEW.id::text, 1, 4)
  );

  -- Ensure uniqueness
  WHILE EXISTS (SELECT 1 FROM public.profiles WHERE username = _username) LOOP
    _username := _username || floor(random() * 100)::text;
  END LOOP;

  INSERT INTO public.profiles (id, username, display_name, referral_code)
  VALUES (
    NEW.id,
    _username,
    COALESCE(NEW.raw_user_meta_data->>'display_name', _username),
    upper(substr(md5(NEW.id::text), 1, 8))
  );

  -- Default role
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');

  -- Promote reserved admins
  SELECT role INTO _reserved_role FROM public.reserved_admins WHERE username = _username;
  IF _reserved_role IS NOT NULL THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, _reserved_role);
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- updated_at helper
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER profiles_touch BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- =====================================================================
-- CHALLENGES
-- =====================================================================
CREATE TABLE public.challenges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  language public.code_language NOT NULL,
  difficulty public.difficulty_tier NOT NULL,
  starter_code TEXT DEFAULT '',
  expected_output TEXT,
  rubric TEXT,
  hints TEXT[] DEFAULT ARRAY[]::TEXT[],
  time_limit_seconds INT DEFAULT 300,
  base_xp INT DEFAULT 50,
  base_coins INT DEFAULT 25,
  tags TEXT[] DEFAULT ARRAY[]::TEXT[],
  active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.challenges ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_challenges_lang_diff ON public.challenges(language, difficulty) WHERE active;

CREATE TABLE public.submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  challenge_id UUID REFERENCES public.challenges(id) ON DELETE CASCADE NOT NULL,
  battle_id UUID,
  code TEXT NOT NULL,
  passed BOOLEAN DEFAULT false,
  score INT DEFAULT 0,
  time_taken_seconds INT,
  ai_feedback TEXT,
  mode TEXT DEFAULT 'practice',
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_subs_user ON public.submissions(user_id, created_at DESC);

CREATE TABLE public.cheat_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  event_type TEXT NOT NULL,
  severity INT DEFAULT 1,
  details JSONB DEFAULT '{}'::JSONB,
  challenge_id UUID,
  battle_id UUID,
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.cheat_events ENABLE ROW LEVEL SECURITY;

-- =====================================================================
-- LEDGERS
-- =====================================================================
CREATE TABLE public.xp_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  amount INT NOT NULL,
  reason TEXT NOT NULL,
  ref_id UUID,
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.xp_ledger ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.coin_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  amount INT NOT NULL,
  reason TEXT NOT NULL,
  ref_id UUID,
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.coin_ledger ENABLE ROW LEVEL SECURITY;

-- =====================================================================
-- SHOP / INVENTORY / CHARACTERS / ACHIEVEMENTS
-- =====================================================================
CREATE TABLE public.shop_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  category TEXT,
  price_coins INT NOT NULL DEFAULT 0,
  price_gems INT NOT NULL DEFAULT 0,
  icon TEXT,
  rarity TEXT DEFAULT 'common',
  consumable BOOLEAN DEFAULT true,
  effect JSONB DEFAULT '{}'::JSONB,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.shop_items ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  item_id UUID REFERENCES public.shop_items(id) NOT NULL,
  qty INT DEFAULT 1,
  total_coins INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.inventory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  item_id UUID REFERENCES public.shop_items(id) NOT NULL,
  qty INT DEFAULT 1,
  acquired_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, item_id)
);
ALTER TABLE public.inventory ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.characters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  price_coins INT DEFAULT 0,
  rarity TEXT DEFAULT 'common',
  emoji TEXT,
  color_primary TEXT,
  color_accent TEXT,
  unlock_condition TEXT,
  active BOOLEAN DEFAULT true
);
ALTER TABLE public.characters ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_characters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  character_id UUID REFERENCES public.characters(id) NOT NULL,
  unlocked_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, character_id)
);
ALTER TABLE public.user_characters ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.achievements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  xp_reward INT DEFAULT 100,
  coin_reward INT DEFAULT 50,
  hidden BOOLEAN DEFAULT false
);
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_achievements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  achievement_id UUID REFERENCES public.achievements(id) NOT NULL,
  unlocked_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, achievement_id)
);
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;

-- =====================================================================
-- HOUSES
-- =====================================================================
CREATE TABLE public.house_tiers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  price_coins INT DEFAULT 0,
  grid_w INT DEFAULT 8,
  grid_h INT DEFAULT 6,
  bg_gradient TEXT,
  theme TEXT
);
ALTER TABLE public.house_tiers ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.houses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  tier_id UUID REFERENCES public.house_tiers(id) NOT NULL,
  name TEXT DEFAULT 'My Crib',
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.houses ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.house_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  emoji TEXT,
  category TEXT,
  price_coins INT DEFAULT 0,
  width INT DEFAULT 1,
  height INT DEFAULT 1
);
ALTER TABLE public.house_items ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.house_placements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  house_id UUID REFERENCES public.houses(id) ON DELETE CASCADE NOT NULL,
  item_id UUID REFERENCES public.house_items(id) NOT NULL,
  pos_x INT NOT NULL,
  pos_y INT NOT NULL,
  rotation INT DEFAULT 0
);
ALTER TABLE public.house_placements ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.house_likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  house_id UUID REFERENCES public.houses(id) ON DELETE CASCADE NOT NULL,
  liker_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(house_id, liker_id)
);
ALTER TABLE public.house_likes ENABLE ROW LEVEL SECURITY;

-- =====================================================================
-- BATTLES
-- =====================================================================
CREATE TABLE public.battles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge_id UUID REFERENCES public.challenges(id) NOT NULL,
  status public.battle_status DEFAULT 'waiting',
  ranked BOOLEAN DEFAULT false,
  winner_id UUID,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.battles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.battle_participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  battle_id UUID REFERENCES public.battles(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  progress INT DEFAULT 0,
  finished BOOLEAN DEFAULT false,
  passed BOOLEAN DEFAULT false,
  finished_at TIMESTAMPTZ,
  UNIQUE(battle_id, user_id)
);
ALTER TABLE public.battle_participants ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.matchmaking_queue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  rank_tier public.rank_tier NOT NULL,
  ranked BOOLEAN DEFAULT true,
  language public.code_language,
  joined_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.matchmaking_queue ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.rank_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  delta INT NOT NULL,
  new_points INT NOT NULL,
  new_tier public.rank_tier NOT NULL,
  reason TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.rank_history ENABLE ROW LEVEL SECURITY;

-- =====================================================================
-- SOCIAL & ENGAGEMENT
-- =====================================================================
CREATE TABLE public.friend_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  from_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  to_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  status public.friend_status DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(from_id, to_id)
);
ALTER TABLE public.friend_requests ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.friends (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_a UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  user_b UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_a, user_b),
  CHECK (user_a < user_b)
);
ALTER TABLE public.friends ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  channel TEXT NOT NULL DEFAULT 'global',
  content TEXT NOT NULL,
  deleted BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_chat_channel ON public.chat_messages(channel, created_at DESC);

CREATE TABLE public.daily_quests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  goal_type TEXT,
  goal_value INT DEFAULT 1,
  xp_reward INT DEFAULT 50,
  coin_reward INT DEFAULT 25
);
ALTER TABLE public.daily_quests ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_quests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  quest_id UUID REFERENCES public.daily_quests(id) NOT NULL,
  progress INT DEFAULT 0,
  completed BOOLEAN DEFAULT false,
  claimed BOOLEAN DEFAULT false,
  date DATE DEFAULT CURRENT_DATE,
  UNIQUE(user_id, quest_id, date)
);
ALTER TABLE public.user_quests ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.spin_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  reward TEXT NOT NULL,
  amount INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.spin_history ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.tournaments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  language public.code_language,
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  prize_pool INT DEFAULT 0,
  status TEXT DEFAULT 'upcoming',
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.tournaments ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.tournament_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_id UUID REFERENCES public.tournaments(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  score INT DEFAULT 0,
  rank INT,
  UNIQUE(tournament_id, user_id)
);
ALTER TABLE public.tournament_entries ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.battle_pass_seasons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  active BOOLEAN DEFAULT true,
  rewards JSONB DEFAULT '[]'::JSONB
);
ALTER TABLE public.battle_pass_seasons ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.battle_pass_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  season_id UUID REFERENCES public.battle_pass_seasons(id) ON DELETE CASCADE NOT NULL,
  xp INT DEFAULT 0,
  premium BOOLEAN DEFAULT false,
  claimed_tiers INT[] DEFAULT ARRAY[]::INT[],
  UNIQUE(user_id, season_id)
);
ALTER TABLE public.battle_pass_progress ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.announcements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  body TEXT,
  level TEXT DEFAULT 'info',
  active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID REFERENCES auth.users(id),
  action TEXT NOT NULL,
  target_id UUID,
  details JSONB DEFAULT '{}'::JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.profile_likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  liker_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(profile_id, liker_id)
);
ALTER TABLE public.profile_likes ENABLE ROW LEVEL SECURITY;

-- =====================================================================
-- RLS POLICIES
-- =====================================================================
-- Profiles: public read, owner update
CREATE POLICY "profiles_select_all" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "profiles_admin_update" ON public.profiles FOR UPDATE USING (public.is_admin(auth.uid()));

-- user_roles: read own + admin read all; only admins insert
CREATE POLICY "roles_select_own" ON public.user_roles FOR SELECT USING (auth.uid() = user_id OR public.is_admin(auth.uid()));
CREATE POLICY "roles_insert_admin" ON public.user_roles FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'super_admin'));
CREATE POLICY "roles_delete_admin" ON public.user_roles FOR DELETE USING (public.has_role(auth.uid(), 'super_admin'));

-- reserved_admins: admin only
CREATE POLICY "reserved_admin_only" ON public.reserved_admins FOR SELECT USING (public.has_role(auth.uid(), 'super_admin'));

-- Challenges: anyone signed in can read; admins write
CREATE POLICY "challenges_select_all" ON public.challenges FOR SELECT USING (active OR public.is_admin(auth.uid()));
CREATE POLICY "challenges_admin_write" ON public.challenges FOR ALL USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

-- Submissions: own
CREATE POLICY "subs_select_own" ON public.submissions FOR SELECT USING (auth.uid() = user_id OR public.is_admin(auth.uid()));
CREATE POLICY "subs_insert_own" ON public.submissions FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Cheat events: admins read; users insert their own (logging from client)
CREATE POLICY "cheat_admin_read" ON public.cheat_events FOR SELECT USING (public.is_admin(auth.uid()) OR auth.uid() = user_id);
CREATE POLICY "cheat_insert_own" ON public.cheat_events FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Ledgers: read own
CREATE POLICY "xp_select_own" ON public.xp_ledger FOR SELECT USING (auth.uid() = user_id OR public.is_admin(auth.uid()));
CREATE POLICY "coin_select_own" ON public.coin_ledger FOR SELECT USING (auth.uid() = user_id OR public.is_admin(auth.uid()));

-- Shop / inventory / characters
CREATE POLICY "shop_select_all" ON public.shop_items FOR SELECT USING (active OR public.is_admin(auth.uid()));
CREATE POLICY "shop_admin_write" ON public.shop_items FOR ALL USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "purchases_own" ON public.purchases FOR SELECT USING (auth.uid() = user_id OR public.is_admin(auth.uid()));
CREATE POLICY "inventory_own" ON public.inventory FOR SELECT USING (auth.uid() = user_id OR public.is_admin(auth.uid()));

CREATE POLICY "chars_select_all" ON public.characters FOR SELECT USING (active);
CREATE POLICY "chars_admin_write" ON public.characters FOR ALL USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "uchars_own" ON public.user_characters FOR SELECT USING (true);

CREATE POLICY "ach_all" ON public.achievements FOR SELECT USING (true);
CREATE POLICY "uach_all" ON public.user_achievements FOR SELECT USING (true);

-- Houses
CREATE POLICY "house_tiers_all" ON public.house_tiers FOR SELECT USING (true);
CREATE POLICY "house_items_all" ON public.house_items FOR SELECT USING (true);
CREATE POLICY "houses_select_all" ON public.houses FOR SELECT USING (true);
CREATE POLICY "houses_modify_own" ON public.houses FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "house_place_select" ON public.house_placements FOR SELECT USING (true);
CREATE POLICY "house_place_modify" ON public.house_placements FOR ALL USING (
  EXISTS (SELECT 1 FROM public.houses h WHERE h.id = house_id AND h.user_id = auth.uid())
) WITH CHECK (
  EXISTS (SELECT 1 FROM public.houses h WHERE h.id = house_id AND h.user_id = auth.uid())
);
CREATE POLICY "house_likes_all" ON public.house_likes FOR SELECT USING (true);
CREATE POLICY "house_likes_insert" ON public.house_likes FOR INSERT WITH CHECK (auth.uid() = liker_id);
CREATE POLICY "house_likes_delete_own" ON public.house_likes FOR DELETE USING (auth.uid() = liker_id);

-- Battles
CREATE POLICY "battles_select_all" ON public.battles FOR SELECT USING (true);
CREATE POLICY "bp_select_all" ON public.battle_participants FOR SELECT USING (true);
CREATE POLICY "bp_update_own" ON public.battle_participants FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "queue_select_all" ON public.matchmaking_queue FOR SELECT USING (true);
CREATE POLICY "queue_modify_own" ON public.matchmaking_queue FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "rank_history_own" ON public.rank_history FOR SELECT USING (auth.uid() = user_id OR public.is_admin(auth.uid()));

-- Friends
CREATE POLICY "fr_select" ON public.friend_requests FOR SELECT USING (auth.uid() IN (from_id, to_id));
CREATE POLICY "fr_insert" ON public.friend_requests FOR INSERT WITH CHECK (auth.uid() = from_id);
CREATE POLICY "fr_update" ON public.friend_requests FOR UPDATE USING (auth.uid() = to_id);
CREATE POLICY "fr_delete" ON public.friend_requests FOR DELETE USING (auth.uid() IN (from_id, to_id));

CREATE POLICY "friends_select" ON public.friends FOR SELECT USING (auth.uid() IN (user_a, user_b));
CREATE POLICY "friends_delete" ON public.friends FOR DELETE USING (auth.uid() IN (user_a, user_b));

-- Chat
CREATE POLICY "chat_select" ON public.chat_messages FOR SELECT USING (NOT deleted OR public.is_admin(auth.uid()));
CREATE POLICY "chat_insert" ON public.chat_messages FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "chat_admin_update" ON public.chat_messages FOR UPDATE USING (public.is_admin(auth.uid()) OR auth.uid() = user_id);

-- Quests / engagement
CREATE POLICY "dq_select" ON public.daily_quests FOR SELECT USING (true);
CREATE POLICY "uq_select_own" ON public.user_quests FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "uq_modify_own" ON public.user_quests FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "spin_select_own" ON public.spin_history FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "tour_select" ON public.tournaments FOR SELECT USING (true);
CREATE POLICY "tour_admin" ON public.tournaments FOR ALL USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "te_select" ON public.tournament_entries FOR SELECT USING (true);
CREATE POLICY "te_insert_own" ON public.tournament_entries FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "bps_select" ON public.battle_pass_seasons FOR SELECT USING (true);
CREATE POLICY "bps_admin" ON public.battle_pass_seasons FOR ALL USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "bpp_select_own" ON public.battle_pass_progress FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "ann_select" ON public.announcements FOR SELECT USING (active OR public.is_admin(auth.uid()));
CREATE POLICY "ann_admin" ON public.announcements FOR ALL USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "audit_admin" ON public.audit_logs FOR SELECT USING (public.is_admin(auth.uid()));

CREATE POLICY "plike_select" ON public.profile_likes FOR SELECT USING (true);
CREATE POLICY "plike_insert" ON public.profile_likes FOR INSERT WITH CHECK (auth.uid() = liker_id);
CREATE POLICY "plike_delete" ON public.profile_likes FOR DELETE USING (auth.uid() = liker_id);

-- =====================================================================
-- REALTIME
-- =====================================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.battles;
ALTER PUBLICATION supabase_realtime ADD TABLE public.battle_participants;
ALTER PUBLICATION supabase_realtime ADD TABLE public.matchmaking_queue;
ALTER PUBLICATION supabase_realtime ADD TABLE public.announcements;
ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
