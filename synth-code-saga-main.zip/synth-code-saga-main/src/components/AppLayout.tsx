import { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { GameNav } from "@/components/GameNav";
import { ParticleBackground } from "@/components/ParticleBackground";
import { FloatingMascot } from "@/components/RobotMascot";

export function AppLayout({ children, requireAuth = true, requireAdmin = false }: { children: ReactNode; requireAuth?: boolean; requireAdmin?: boolean }) {
  const { user, loading, isAdmin } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <div className="animate-spin-slow h-12 w-12 rounded-full border-4 border-primary/30 border-t-primary" />
      </div>
    );
  }
  if (requireAuth && !user) return <Navigate to="/auth" replace />;
  if (requireAdmin && !isAdmin) return <Navigate to="/dashboard" replace />;
  return (
    <div className="min-h-screen relative">
      <ParticleBackground />
      <GameNav />
      <main className="container py-6">{children}</main>
      <FloatingMascot />
    </div>
  );
}
